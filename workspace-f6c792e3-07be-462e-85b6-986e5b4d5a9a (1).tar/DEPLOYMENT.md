# Vercel Deployment Configuration

## Step 1: Install Vercel CLI
```bash
npm i -g vercel
```

## Step 2: Login to Vercel
```bash
vercel login
```

## Step 3: Deploy
```bash
# From your project root
vercel

# Follow the prompts:
# - Link to existing project? No
# - Project name: goalguess (or your choice)
# - Directory: . (current directory)
# - Override settings? No
```

## Step 4: Environment Variables
Set these in Vercel dashboard (Settings > Environment Variables):

### Required:
```
NEXT_PUBLIC_APP_NAME=GoalGuess
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### Optional (if using):
```
ZAI_API_KEY=your_z_ai_api_key
OPENAI_API_KEY=your_openai_key (if using)
```

## Step 5: Automatic Deployments
- Connect your GitHub repository to Vercel
- Every push to main branch triggers automatic deployment
- Preview deployments for every PR

## Build Configuration
Vercel automatically detects Next.js and uses:
- Build Command: `npm run build`
- Output Directory: `.next`
- Install Command: `npm install`

## Custom Domain (Optional)
1. Go to Vercel dashboard > Project > Domains
2. Add your custom domain
3. Update DNS records as instructed

## Performance Optimization
Your app is already configured with:
- ✅ Static generation where possible
- ✅ Image optimization (sharp)
- ✅ SWC minification
- ✅ Compression enabled
- ✅ Standalone output for Docker