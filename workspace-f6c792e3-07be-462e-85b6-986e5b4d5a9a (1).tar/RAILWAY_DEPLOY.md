# Railway Deployment Guide

## Step 1: Install Railway CLI
```bash
npm install -g @railway/cli
```

## Step 2: Login and Setup
```bash
railway login
railway init
```

## Step 3: Configure Environment
Create `railway.toml`:
```toml
[build]
builder = "NIXPACKS"

[deploy]
healthcheckPath = "/api/health"
healthcheckTimeout = 100
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 10

[[services]]
name = "app"
sourceDir = "/"
healthcheckPath = "/api/health"
healthcheckTimeout = 100
```

## Step 4: Deploy
```bash
railway up
```

## Environment Variables in Railway Dashboard:
```
NEXT_PUBLIC_APP_NAME=GoalGuess
NEXT_PUBLIC_APP_URL=https://your-app.railway.app
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
ZAI_API_KEY=your_z_ai_api_key
NODE_ENV=production
PORT=3000
```

## Database Setup (Optional)
Railway also offers PostgreSQL:
1. Add PostgreSQL service in Railway dashboard
2. Get connection string
3. Update your Prisma schema
4. Run: `railway run npx prisma migrate deploy`