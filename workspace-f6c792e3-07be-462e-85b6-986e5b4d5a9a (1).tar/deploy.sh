#!/bin/bash

# GoalGuess Football Dashboard - Deployment Script

echo "🚀 GoalGuess Football Dashboard Deployment"
echo "======================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the project root."
    exit 1
fi

echo "✅ Project detected: GoalGuess Football Dashboard"

# Build the application
echo "📦 Building application..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
else
    echo "❌ Build failed. Please fix the errors above."
    exit 1
fi

# Deployment options
echo ""
echo "🌐 Choose deployment platform:"
echo "1) Vercel (Recommended)"
echo "2) Railway"
echo "3) Netlify"
echo "4) Docker (Self-hosted)"
echo ""
read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo "🚀 Deploying to Vercel..."
        echo "Please follow these steps:"
        echo "1. Install Vercel CLI: npm install -g vercel (may need sudo)"
        echo "2. Login: vercel login"
        echo "3. Deploy: vercel"
        echo "4. Set environment variables in Vercel dashboard"
        ;;
    2)
        echo "🚀 Deploying to Railway..."
        echo "Please follow these steps:"
        echo "1. Install Railway CLI: npm install -g @railway/cli"
        echo "2. Login: railway login"
        echo "3. Deploy: railway up"
        echo "4. Set environment variables in Railway dashboard"
        ;;
    3)
        echo "🚀 Deploying to Netlify..."
        echo "Please follow these steps:"
        echo "1. Install Netlify CLI: npm install -g netlify-cli"
        echo "2. Login: netlify login"
        echo "3. Deploy: netlify deploy --prod --dir=.next"
        ;;
    4)
        echo "🐳 Deploying with Docker..."
        echo "Please follow these steps:"
        echo "1. Build Docker image: docker build -t goalguess ."
        echo "2. Run container: docker run -p 3000:3000 goalguess"
        echo "3. For production: Use docker-compose up"
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "📋 Required Environment Variables:"
echo "- NEXT_PUBLIC_APP_NAME=GoalGuess"
echo "- NEXT_PUBLIC_APP_URL=https://your-domain.com"
echo "- NEXT_PUBLIC_SUPABASE_URL=your_supabase_url"
echo "- NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key"
echo "- ZAI_API_KEY=your_z_ai_api_key"
echo ""
echo "🎉 Deployment guide created in DEPLOYMENT.md"
echo "📖 Read the full deployment documentation there."