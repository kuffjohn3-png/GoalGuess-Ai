import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import cors from 'cors'

const server = createServer()
const io = new SocketIOServer(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
})

// Mock live match data
let liveMatches = [
  {
    id: '1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    status: 'live',
    minute: 67,
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    attendance: 55000,
    homeTeamStats: {
      possession: 62,
      shots: 14,
      shotsOnTarget: 6,
      corners: 7,
      fouls: 8,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 38,
      shots: 8,
      shotsOnTarget: 3,
      corners: 3,
      fouls: 12,
      yellowCards: 2,
      redCards: 0
    },
    lastUpdate: new Date()
  },
  {
    id: '2',
    homeTeam: 'Real Madrid',
    awayTeam: 'Barcelona',
    homeScore: 0,
    awayScore: 0,
    status: 'live',
    minute: 34,
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Santiago Bernabéu',
    attendance: 80000,
    homeTeamStats: {
      possession: 55,
      shots: 9,
      shotsOnTarget: 2,
      corners: 4,
      fouls: 6,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 45,
      shots: 7,
      shotsOnTarget: 2,
      corners: 2,
      fouls: 9,
      yellowCards: 2,
      redCards: 0
    },
    lastUpdate: new Date()
  }
]

// Simulate real-time match updates
function simulateMatchUpdates() {
  setInterval(() => {
    liveMatches = liveMatches.map(match => {
      if (match.status === 'live' && match.minute) {
        const updatedMatch = { ...match }
        
        // Increment minute
        updatedMatch.minute = Math.min(match.minute + 1, 90)
        
        // Random events
        const eventChance = Math.random()
        
        if (eventChance < 0.05) { // 5% chance of goal
          const teamScores = Math.random() < 0.6 // 60% chance home team scores
          if (teamScores) {
            updatedMatch.homeScore += 1
            updatedMatch.homeTeamStats!.shots += 1
            updatedMatch.homeTeamStats!.shotsOnTarget += 1
          } else {
            updatedMatch.awayScore += 1
            updatedMatch.awayTeamStats!.shots += 1
            updatedMatch.awayTeamStats!.shotsOnTarget += 1
          }
          
          // Emit goal event
          io.emit('goal', {
            matchId: match.id,
            team: teamScores ? match.homeTeam : match.awayTeam,
            score: `${updatedMatch.homeScore} - ${updatedMatch.awayScore}`,
            minute: updatedMatch.minute
          })
        } else if (eventChance < 0.15) { // 10% chance of yellow card
          const homeTeamCard = Math.random() < 0.5
          if (homeTeamCard) {
            updatedMatch.homeTeamStats!.yellowCards += 1
          } else {
            updatedMatch.awayTeamStats!.yellowCards += 1
          }
        } else if (eventChance < 0.18) { // 3% chance of corner
          const homeTeamCorner = Math.random() < 0.6
          if (homeTeamCorner) {
            updatedMatch.homeTeamStats!.corners += 1
          } else {
            updatedMatch.awayTeamStats!.corners += 1
          }
        }
        
        // Update possession slightly
        const possessionChange = (Math.random() - 0.5) * 2
        updatedMatch.homeTeamStats!.possession = Math.max(30, Math.min(70, 
          updatedMatch.homeTeamStats!.possession + possessionChange))
        updatedMatch.awayTeamStats!.possession = 100 - updatedMatch.homeTeamStats!.possession
        
        // Update shots occasionally
        if (Math.random() < 0.3) {
          const homeTeamShot = Math.random() < 0.55
          if (homeTeamShot) {
            updatedMatch.homeTeamStats!.shots += 1
            if (Math.random() < 0.4) {
              updatedMatch.homeTeamStats!.shotsOnTarget += 1
            }
          } else {
            updatedMatch.awayTeamStats!.shots += 1
            if (Math.random() < 0.4) {
              updatedMatch.awayTeamStats!.shotsOnTarget += 1
            }
          }
        }
        
        // Update fouls occasionally
        if (Math.random() < 0.2) {
          const homeTeamFoul = Math.random() < 0.5
          if (homeTeamFoul) {
            updatedMatch.homeTeamStats!.fouls += 1
          } else {
            updatedMatch.awayTeamStats!.fouls += 1
          }
        }
        
        updatedMatch.lastUpdate = new Date()
        
        // Check if match should end
        if (updatedMatch.minute >= 90) {
          updatedMatch.status = 'finished'
          io.emit('matchFinished', {
            matchId: match.id,
            finalScore: `${updatedMatch.homeScore} - ${updatedMatch.awayScore}`,
            winner: updatedMatch.homeScore > updatedMatch.awayScore ? updatedMatch.homeTeam :
                    updatedMatch.awayScore > updatedMatch.homeScore ? updatedMatch.awayTeam : 'Draw'
          })
        }
        
        return updatedMatch
      }
      return match
    })
    
    // Emit updated matches to all connected clients
    io.emit('matchUpdate', liveMatches)
  }, 5000) // Update every 5 seconds
}

// Handle socket connections
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`)
  
  // Send current matches when client connects
  socket.emit('matchUpdate', liveMatches)
  
  // Handle disconnection
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`)
  })
  
  // Handle specific match subscription
  socket.on('subscribeMatch', (matchId: string) => {
    socket.join(`match-${matchId}`)
    console.log(`Client ${socket.id} subscribed to match ${matchId}`)
  })
  
  // Handle unsubscribe from match
  socket.on('unsubscribeMatch', (matchId: string) => {
    socket.leave(`match-${matchId}`)
    console.log(`Client ${socket.id} unsubscribed from match ${matchId}`)
  })
  
  // Handle request for match stats
  socket.on('getMatchStats', (matchId: string) => {
    const match = liveMatches.find(m => m.id === matchId)
    if (match) {
      socket.emit('matchStats', {
        matchId,
        stats: {
          homeTeam: match.homeTeamStats,
          awayTeam: match.awayTeamStats
        }
      })
    }
  })
})

// Start simulation
simulateMatchUpdates()

// Start server
const PORT = 3002
server.listen(PORT, () => {
  console.log(`Livescore WebSocket service running on port ${PORT}`)
})