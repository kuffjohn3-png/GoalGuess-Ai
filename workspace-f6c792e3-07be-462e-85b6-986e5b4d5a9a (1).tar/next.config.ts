import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  // 禁用 Next.js 热重载，由 nodemon 处理重编译
  reactStrictMode: false,
  eslint: {
    // 构建时忽略ESLint错误
    ignoreDuringBuilds: true,
  },
  // Vercel deployment configuration
  env: {
    NEXT_PUBLIC_APP_NAME: 'GoalGuess',
    NEXT_PUBLIC_APP_URL: 'https://www.goalguess.com',
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  },
  // Generate source maps for better debugging
  productionBrowserSourceMaps: false,
  // Optimize for deployment
  compress: true,
};

export default nextConfig;
