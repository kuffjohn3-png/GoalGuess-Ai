import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

interface NewsletterRequest {
  matchId?: string
  league?: string
  teams?: string[]
  preferences?: {
    riskLevel: 'low' | 'medium' | 'high'
    predictionType: 'winner' | 'score' | 'both'
    analysisDepth: 'basic' | 'detailed' | 'comprehensive'
  }
}

interface AgentAnalysis {
  agent: string
  expertise: string
  prediction: any
  confidence: number
  reasoning: string
  keyFactors: string[]
}

export async function POST(request: NextRequest) {
  try {
    const body: NewsletterRequest = await request.json()
    const { matchId, league, teams, preferences = { riskLevel: 'medium', predictionType: 'both', analysisDepth: 'detailed' } } = body

    const zai = await ZAI.create()

    // Multi-Agent Analysis System
    const agents = [
      {
        name: 'Statistical Analyst',
        expertise: 'Historical data analysis, form trends, statistical modeling',
        prompt: 'As a statistical analyst specializing in football predictions, analyze upcoming match data. Focus on: - Historical head-to-head records - Current team form and trends - Statistical patterns and probabilities - Performance metrics and indicators Provide a data-driven prediction with confidence levels and key statistical factors.'
      },
      {
        name: 'Performance Expert',
        expertise: 'Player performance, injuries, tactical analysis',
        prompt: 'As a football performance expert, analyze team and player factors. Consider: - Key player availability and injuries - Recent individual performances - Tactical matchups and formations - Team chemistry and morale - Managerial impact Provide performance-based prediction with player insights and tactical considerations.'
      },
      {
        name: 'Market Intelligence',
        expertise: 'Betting odds, market sentiment, external factors',
        prompt: 'As a market intelligence analyst, evaluate external factors. Analyze: - Betting market movements and odds - Media sentiment and news impact - Weather and venue conditions - Motivational factors (titles, relegation, etc.) - Historical pressure situations Provide market-informed prediction with external factor analysis.'
      },
      {
        name: 'AI Prediction Engine',
        expertise: 'Machine learning models, pattern recognition',
        prompt: 'As an AI prediction engine, use advanced analytics to: - Identify complex patterns in historical data - Apply machine learning models - Calculate probability distributions - Simulate match outcomes - Generate ensemble predictions Provide AI-driven prediction with probability scores and model confidence.'
      }
    ]

    const analyses: AgentAnalysis[] = []

    // Run each agent analysis
    for (const agent of agents) {
      try {
        const context = teams && teams.length === 2 
          ? `Match: ${teams[0]} vs ${teams[1]} in ${league || 'their league'}`
          : `Analyzing matches in ${league || 'football'} with risk level: ${preferences.riskLevel}`

        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: agent.prompt
            },
            {
              role: 'user',
              content: `${context}\n\nProvide analysis in JSON format:
              {
                "prediction": {
                  "winner": "Team Name or Draw",
                  "confidence": 0-100,
                  "score": {"home": 0, "away": 0},
                  "riskLevel": "low|medium|high"
                },
                "reasoning": "Brief explanation",
                "keyFactors": ["factor1", "factor2", "factor3"]
              }`
            }
          ],
          temperature: 0.3,
          max_tokens: 500
        })

        const responseText = completion.choices[0]?.message?.content
        
        if (responseText) {
          let analysis
          try {
            analysis = JSON.parse(responseText)
          } catch {
            analysis = {
              prediction: {
                winner: "Analysis pending",
                confidence: 50,
                score: { home: 0, away: 0 },
                riskLevel: preferences.riskLevel
              },
              reasoning: responseText,
              keyFactors: ["Processing analysis"]
            }
          }

          analyses.push({
            agent: agent.name,
            expertise: agent.expertise,
            prediction: analysis.prediction,
            confidence: analysis.prediction.confidence,
            reasoning: analysis.reasoning,
            keyFactors: analysis.keyFactors
          })
        }
      } catch (error) {
        console.error(`Error in ${agent.name} analysis:`, error)
      }
    }

    // Ensemble prediction combining all agents
    const ensemblePrediction = generateEnsemblePrediction(analyses, preferences)

    // Generate newsletter content
    const newsletter = await generateNewsletterContent(analyses, ensemblePrediction, preferences)

    return NextResponse.json({
      success: true,
      matchId,
      league,
      timestamp: new Date().toISOString(),
      analyses,
      ensemblePrediction,
      newsletter,
      metadata: {
        agentsUsed: agents.length,
        analysisDepth: preferences.analysisDepth,
        predictionType: preferences.predictionType,
        riskLevel: preferences.riskLevel
      }
    })

  } catch (error: any) {
    console.error('AI Newsletter API error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to generate AI newsletter',
        message: error.message,
        success: false 
      },
      { status: 500 }
    )
  }
}

function generateEnsemblePrediction(analyses: AgentAnalysis[], preferences: NewsletterRequest['preferences']) {
  // Weighted ensemble based on agent confidence
  const validAnalyses = analyses.filter(a => a.prediction && a.confidence > 0)
  
  if (validAnalyses.length === 0) {
    return {
      winner: "Insufficient data",
      confidence: 0,
      score: { home: 0, away: 0 },
      riskLevel: preferences?.riskLevel || 'medium'
    }
  }

  // Calculate weighted prediction
  const weights = validAnalyses.map(a => a.confidence / 100)
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0)
  
  const winnerVotes = validAnalyses.reduce((votes: Record<string, number>, analysis) => {
    const winner = analysis.prediction.winner
    if (winner && winner !== "Insufficient data") {
      votes[winner] = (votes[winner] || 0) + analysis.confidence
    }
    return votes
  }, {})

  const ensembleWinner = Object.entries(winnerVotes).reduce((best, [team, votes]) => 
    votes > best.votes ? { team, votes } : best, { team: '', votes: 0 }
  ).team

  const avgConfidence = validAnalyses.reduce((sum, a) => sum + a.confidence, 0) / validAnalyses.length

  return {
    winner: ensembleWinner,
    confidence: Math.round(avgConfidence),
    consensus: Object.keys(winnerVotes).length === 1 ? 'high' : 'medium',
    score: predictScore(validAnalyses),
    riskLevel: calculateRiskLevel(validAnalyses, preferences?.riskLevel)
  }
}

function predictScore(analyses: AgentAnalysis[]) {
  const scoreAnalyses = analyses.filter(a => a.prediction.score)
  if (scoreAnalyses.length === 0) return { home: 0, away: 0 }

  const avgHome = scoreAnalyses.reduce((sum, a) => sum + a.prediction.score.home, 0) / scoreAnalyses.length
  const avgAway = scoreAnalyses.reduce((sum, a) => sum + a.prediction.score.away, 0) / scoreAnalyses.length

  return {
    home: Math.round(avgHome),
    away: Math.round(avgAway)
  }
}

function calculateRiskLevel(analyses: AgentAnalysis[], userRiskLevel?: string) {
  const confidences = analyses.map(a => a.confidence)
  const avgConfidence = confidences.reduce((sum, c) => sum + c, 0) / confidences.length
  
  if (avgConfidence > 75) return 'low'
  if (avgConfidence > 60) return 'medium'
  return 'high'
}

async function generateNewsletterContent(analyses: AgentAnalysis[], ensemblePrediction: any, preferences: NewsletterRequest['preferences']) {
  const zai = await ZAI.create()
  
  const prompt = `As a sports newsletter editor, create a comprehensive football prediction newsletter based on the following multi-agent analysis:

ANALYSES:
${analyses.map(a => `
${a.agent} (${a.expertise}):
- Prediction: ${a.prediction.winner} (${a.confidence}% confidence)
- Reasoning: ${a.reasoning}
- Key Factors: ${a.keyFactors.join(', ')}
`).join('\n')}

ENSEMBLE PREDICTION:
- Winner: ${ensemblePrediction.winner}
- Confidence: ${ensemblePrediction.confidence}%
- Consensus: ${ensemblePrediction.consensus}
- Risk Level: ${ensemblePrediction.riskLevel}

Create an engaging newsletter with:
1. Catchy headline
2. Executive summary of predictions
3. Key insights from each agent
4. Final recommendation
5. Risk assessment
6. Betting considerations (if applicable)

Format as JSON:
{
  "headline": "Engaging headline",
  "summary": "Executive summary",
  "insights": ["insight1", "insight2"],
  "recommendation": "Final recommendation",
  "riskAssessment": "Risk analysis",
  "bettingConsiderations": "Betting advice"
}

Use a professional but engaging tone suitable for football fans.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
      max_tokens: 800
    })

    const responseText = completion.choices[0]?.message?.content
    
    if (responseText) {
      try {
        return JSON.parse(responseText)
      } catch {
        return {
          headline: "AI Football Predictions",
          summary: "Analysis completed successfully",
          insights: ["Multi-agent analysis", "Comprehensive evaluation"],
          recommendation: ensemblePrediction.winner || "Check predictions",
          riskAssessment: `Risk level: ${ensemblePrediction.riskLevel}`,
          bettingConsiderations: "Please bet responsibly"
        }
      }
    }
  } catch (error) {
    console.error('Newsletter generation error:', error)
  }

  return {
    headline: "AI Football Predictions",
    summary: "Analysis completed successfully",
    insights: ["Multi-agent analysis", "Comprehensive evaluation"],
    recommendation: "Check detailed predictions",
    riskAssessment: `Risk: ${ensemblePrediction.riskLevel}`,
    bettingConsiderations: "Please bet responsibly"
  }
}