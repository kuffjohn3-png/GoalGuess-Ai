import { NextResponse } from 'next/server'

const enhancedLeagues = [
  // Major European Leagues
  { 
    id: '1', 
    name: 'Premier League', 
    country: 'England', 
    flag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-19',
    level: 'Tier 1',
    popularity: 95,
    predictionAccuracy: 78
  },
  { 
    id: '2', 
    name: 'La Liga', 
    country: 'Spain', 
    flag: '🇪🇸', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-26',
    level: 'Tier 1',
    popularity: 92,
    predictionAccuracy: 81
  },
  { 
    id: '3', 
    name: 'Bundesliga', 
    country: 'Germany', 
    flag: '🇩🇪', 
    matches: 306, 
    teams: 18,
    season: '2023/24',
    startDate: '2023-08-18',
    endDate: '2024-05-18',
    level: 'Tier 1',
    popularity: 88,
    predictionAccuracy: 75
  },
  { 
    id: '4', 
    name: 'Serie A', 
    country: 'Italy', 
    flag: '🇮🇹', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-19',
    endDate: '2024-05-26',
    level: 'Tier 1',
    popularity: 85,
    predictionAccuracy: 73
  },
  { 
    id: '5', 
    name: 'Ligue 1', 
    country: 'France', 
    flag: '🇫🇷', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-25',
    level: 'Tier 1',
    popularity: 78,
    predictionAccuracy: 76
  },
  
  // Secondary European Leagues
  { 
    id: '6', 
    name: 'Eredivisie', 
    country: 'Netherlands', 
    flag: '🇳🇱', 
    matches: 306, 
    teams: 18,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-12',
    level: 'Tier 1',
    popularity: 72,
    predictionAccuracy: 71
  },
  { 
    id: '7', 
    name: 'Primeira Liga', 
    country: 'Portugal', 
    flag: '🇵🇹', 
    matches: 306, 
    teams: 18,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-19',
    level: 'Tier 1',
    popularity: 69,
    predictionAccuracy: 69
  },
  { 
    id: '8', 
    name: 'Russian Premier League', 
    country: 'Russia', 
    flag: '🇷🇺', 
    matches: 240, 
    teams: 16,
    season: '2023/24',
    startDate: '2023-07-21',
    endDate: '2024-05-25',
    level: 'Tier 1',
    popularity: 65,
    predictionAccuracy: 67
  },
  
  // South American Leagues
  { 
    id: '9', 
    name: 'Brasileirão', 
    country: 'Brazil', 
    flag: '🇧🇷', 
    matches: 380, 
    teams: 20,
    season: '2023',
    startDate: '2023-04-15',
    endDate: '2023-12-03',
    level: 'Tier 1',
    popularity: 82,
    predictionAccuracy: 74
  },
  { 
    id: '10', 
    name: 'Liga Profesional', 
    country: 'Argentina', 
    flag: '🇦🇷', 
    matches: 276, 
    teams: 28,
    season: '2023',
    startDate: '2023-04-28',
    endDate: '2023-11-06',
    level: 'Tier 1',
    popularity: 76,
    predictionAccuracy: 72
  },
  
  // North American Leagues
  { 
    id: '11', 
    name: 'MLS', 
    country: 'USA', 
    flag: '🇺🇸', 
    matches: 342, 
    teams: 29,
    season: '2023',
    startDate: '2023-02-25',
    endDate: '2023-10-21',
    level: 'Tier 1',
    popularity: 74,
    predictionAccuracy: 70
  },
  { 
    id: '12', 
    name: 'Liga MX', 
    country: 'Mexico', 
    flag: '🇲🇽', 
    matches: 306, 
    teams: 18,
    season: '2023',
    startDate: '2023-01-06',
    endDate: '2023-05-15',
    level: 'Tier 1',
    popularity: 68,
    predictionAccuracy: 68
  },
  
  // Asian Leagues
  { 
    id: '13', 
    name: 'J1 League', 
    country: 'Japan', 
    flag: '🇯🇵', 
    matches: 306, 
    teams: 18,
    season: '2023',
    startDate: '2023-02-17',
    endDate: '2023-12-03',
    level: 'Tier 1',
    popularity: 71,
    predictionAccuracy: 70
  },
  { 
    id: '14', 
    name: 'K League 1', 
    country: 'South Korea', 
    flag: '🇰🇷', 
    matches: 228, 
    teams: 12,
    season: '2023',
    startDate: '2023-02-25',
    endDate: '2023-12-02',
    level: 'Tier 1',
    popularity: 64,
    predictionAccuracy: 66
  },
  
  // African Leagues
  { 
    id: '15', 
    name: 'Egyptian Premier League', 
    country: 'Egypt', 
    flag: '🇪🇬', 
    matches: 180, 
    teams: 18,
    season: '2023/24',
    startDate: '2023-09-18',
    endDate: '2024-06-30',
    level: 'Tier 1',
    popularity: 62,
    predictionAccuracy: 65
  },
  
  // Continental Competitions
  {
    id: '16',
    name: 'Champions League',
    country: 'Europe',
    flag: '🏆',
    matches: 125,
    teams: 32,
    season: '2023/24',
    startDate: '2023-09-19',
    endDate: '2024-06-01',
    level: 'Continental',
    popularity: 98,
    predictionAccuracy: 84
  },
  {
    id: '17',
    name: 'Europa League',
    country: 'Europe',
    flag: '🌍',
    matches: 141,
    teams: 32,
    season: '2023/24',
    startDate: '2023-09-21',
    endDate: '2024-05-22',
    level: 'Continental',
    popularity: 91,
    predictionAccuracy: 79
  },
  {
    id: '18',
    name: 'Copa Libertadores',
    country: 'South America',
    flag: '🌎',
    matches: 138,
    teams: 47,
    season: '2023',
    startDate: '2023-04-04',
    endDate: '2023-11-01',
    level: 'Continental',
    popularity: 85,
    predictionAccuracy: 77
  }
]

const enhancedStandings = {
  '1': [ // Premier League
    { position: 1, team: 'Manchester City', played: 25, won: 18, drawn: 4, lost: 3, goalsFor: 52, goalsAgainst: 24, points: 58, form: 'WWWWW' },
    { position: 2, team: 'Liverpool', played: 25, won: 17, drawn: 5, lost: 3, goalsFor: 48, goalsAgainst: 22, points: 56, form: 'WWLWW' },
    { position: 3, team: 'Arsenal', played: 25, won: 16, drawn: 5, lost: 4, goalsFor: 45, goalsAgainst: 23, points: 53, form: 'WDWWD' },
    { position: 4, team: 'Chelsea', played: 25, won: 14, drawn: 6, lost: 5, goalsFor: 42, goalsAgainst: 28, points: 48, form: 'LWDWL' },
    { position: 5, team: 'Tottenham', played: 25, won: 13, drawn: 5, lost: 7, goalsFor: 40, goalsAgainst: 30, points: 44, form: 'WDLWL' },
    { position: 6, team: 'Aston Villa', played: 25, won: 13, drawn: 4, lost: 8, goalsFor: 46, goalsAgainst: 31, points: 43, form: 'WLLDW' },
    { position: 7, team: 'Manchester United', played: 25, won: 12, drawn: 4, lost: 9, goalsFor: 35, goalsAgainst: 34, points: 40, form: 'LDLLW' },
    { position: 8, team: 'West Ham', played: 25, won: 11, drawn: 6, lost: 8, goalsFor: 38, goalsAgainst: 33, points: 39, form: 'DLLWD' }
  ],
  '2': [ // La Liga
    { position: 1, team: 'Real Madrid', played: 24, won: 19, drawn: 3, lost: 2, goalsFor: 46, goalsAgainst: 16, points: 60, form: 'WWWWW' },
    { position: 2, team: 'Barcelona', played: 24, won: 18, drawn: 4, lost: 2, goalsFor: 42, goalsAgainst: 18, points: 58, form: 'WWWLW' },
    { position: 3, team: 'Girona', played: 24, won: 16, drawn: 5, lost: 3, goalsFor: 44, goalsAgainst: 25, points: 53, form: 'WDWWL' },
    { position: 4, team: 'Atletico Madrid', played: 24, won: 14, drawn: 4, lost: 6, goalsFor: 35, goalsAgainst: 22, points: 46, form: 'LWLDW' },
    { position: 5, team: 'Athletic Bilbao', played: 24, won: 13, drawn: 6, lost: 5, goalsFor: 38, goalsAgainst: 27, points: 45, form: 'DWLDL' },
    { position: 6, team: 'Real Sociedad', played: 24, won: 12, drawn: 6, lost: 6, goalsFor: 34, goalsAgainst: 28, points: 42, form: 'LDLWD' },
    { position: 7, team: 'Valencia', played: 24, won: 11, drawn: 5, lost: 8, goalsFor: 32, goalsAgainst: 29, points: 38, form: 'DLLLW' },
    { position: 8, team: 'Villarreal', played: 24, won: 10, drawn: 6, lost: 8, goalsFor: 30, goalsAgainst: 31, points: 36, form: 'LDWDL' }
  ]
}

export async function GET() {
  return NextResponse.json({
    success: true,
    leagues: enhancedLeagues,
    standings: enhancedStandings,
    totalLeagues: enhancedLeagues.length,
    featuredLeagues: enhancedLeagues.filter(l => l.popularity > 80),
    timestamp: new Date().toISOString()
  })
}