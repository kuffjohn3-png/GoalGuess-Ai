import { NextRequest, NextResponse } from 'next/server'

interface Market {
  id: string
  name: string
  type: string
  selections: MarketSelection[]
  odds: {
    home: number
    away: number
    draw: number
  }
  status: 'active' | 'suspended' | 'closed'
}

interface MarketSelection {
  id: string
  name: string
  odds: number
  handicap?: number
  total?: number
  value?: string
}

const mockMarkets: { [key: string]: Market[] } = {
  '1': [ // Manchester City vs Liverpool
    {
      id: 'm1',
      name: 'Match Result',
      type: '1x2',
      selections: [
        { id: 's1', name: 'Manchester City', odds: 1.85 },
        { id: 's2', name: 'Draw', odds: 3.60 },
        { id: 's3', name: 'Liverpool', odds: 4.20 }
      ],
      odds: { home: 1.85, away: 4.20, draw: 3.60 },
      status: 'active'
    },
    {
      id: 'm2',
      name: 'Over/Under 2.5 Goals',
      type: 'total_goals',
      selections: [
        { id: 'ou1', name: 'Over 2.5', odds: 1.95 },
        { id: 'ou2', name: 'Under 2.5', odds: 1.85 }
      ],
      odds: { over: 1.95, under: 1.85 },
      status: 'active'
    },
    {
      id: 'm3',
      name: 'Both Teams to Score',
      type: 'btts',
      selections: [
        { id: 'b1', name: 'Yes', odds: 1.75 },
        { id: 'b2', name: 'No', odds: 2.10 }
      ],
      odds: { yes: 1.75, no: 2.10 },
      status: 'active'
    },
    {
      id: 'm4',
      name: 'Asian Handicap -1.5',
      type: 'asian_handicap',
      selections: [
        { id: 'ah1', name: 'Manchester City -1.5', odds: 1.90 },
        { id: 'ah2', name: 'Liverpool +1.5', odds: 1.95 }
      ],
      odds: { home: 1.90, away: 1.95 },
      status: 'active'
    },
    {
      id: 'm5',
      name: 'Total Corners Over/Under 10.5',
      type: 'corners',
      selections: [
        { id: 'c1', name: 'Over 10.5', odds: 1.80 },
        { id: 'c2', name: 'Under 10.5', odds: 2.00 }
      ],
      odds: { over: 1.80, under: 2.00 },
      status: 'active'
    },
    {
      id: 'm6',
      name: 'Cards Market',
      type: 'cards',
      selections: [
        { id: 'card1', name: 'Over 3.5 Cards', odds: 2.15 },
        { id: 'card2', name: 'Under 3.5 Cards', odds: 1.70 },
        { id: 'card3', name: 'Home Team Over 1.5 Cards', odds: 1.95 },
        { id: 'card4', name: 'Away Team Over 1.5 Cards', odds: 2.25 }
      ],
      odds: { over_35: 2.15, under_35: 1.70, home_over_15: 1.95, away_over_15: 2.25 },
      status: 'active'
    }
  ],
  '2': [ // Real Madrid vs Barcelona
    {
      id: 'm7',
      name: 'Match Result',
      type: '1x2',
      selections: [
        { id: 's1', name: 'Real Madrid', odds: 2.10 },
        { id: 's2', name: 'Draw', odds: 3.40 },
        { id: 's3', name: 'Barcelona', odds: 3.20 }
      ],
      odds: { home: 2.10, away: 3.20, draw: 3.40 },
      status: 'active'
    },
    {
      id: 'm8',
      name: 'First Goalscorer',
      type: 'player_props',
      selections: [
        { id: 'fg1', name: 'Kylian Mbappé', odds: 3.50 },
        { id: 'fg2', name: 'Vinícius Jr', odds: 4.00 },
        { id: 'fg3', name: 'Robert Lewandowski', odds: 6.50 },
        { id: 'fg4', name: 'Jude Bellingham', odds: 5.00 }
      ],
      odds: { mbappe: 3.50, vinicius: 4.00, lewandowski: 6.50, bellingham: 5.00 },
      status: 'active'
    }
  ]
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const matchId = searchParams.get('matchId')
  const marketType = searchParams.get('type')

  try {
    if (matchId && mockMarkets[matchId]) {
      const markets = mockMarkets[matchId]
      
      if (marketType) {
        const filteredMarkets = markets.filter(market => market.type === marketType)
        return NextResponse.json({
          success: true,
          matchId,
          marketType,
          markets: filteredMarkets,
          timestamp: new Date().toISOString()
        })
      }
      
      return NextResponse.json({
        success: true,
        matchId,
        markets,
        timestamp: new Date().toISOString()
      })
    }

    return NextResponse.json({
      success: false,
      error: 'Markets not found for this match',
      matchId
    }, { status: 404 })

  } catch (error) {
    console.error('Markets API error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to fetch markets',
        message: error.message,
        success: false 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, marketId, selectionId, stake } = body

    if (!matchId || !marketId || !selectionId) {
      return NextResponse.json({
        success: false,
        error: 'Missing required fields: matchId, marketId, selectionId'
      }, { status: 400 })
    }

    // Process bet placement
    const betResult = processBet(matchId, marketId, selectionId, stake)

    return NextResponse.json({
      success: true,
      betResult,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Bet placement error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to place bet',
        message: error.message,
        success: false 
      },
      { status: 500 }
    )
  }
}

function processBet(matchId: string, marketId: string, selectionId: string, stake: number) {
  // Simulate bet processing
  const betId = `bet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  
  return {
    betId,
    matchId,
    marketId,
    selectionId,
    stake,
    status: 'pending',
    placedAt: new Date().toISOString(),
    potentialReturn: calculatePotentialReturn(selectionId, stake),
    odds: getOddsForSelection(matchId, selectionId)
  }
}

function getOddsForSelection(matchId: string, marketId: string, selectionId: string): number {
  const oddsData: Record<string, number> = {
    's1': 1.85, 's2': 3.60, 's3': 4.20, // Man City vs Liverpool
    'ou1': 1.95, 'ou2': 1.85, // O/U 2.5
    'b1': 1.75, 'b2': 2.10, // BTTS
    'ah1': 1.90, 'ah2': 1.95, // Asian Handicap -1.5
    'c1': 1.80, 'c2': 2.00, // Corners O/U 10.5
    'card1': 2.15, 'card2': 1.70, 'card3': 1.95, 'card4': 2.25, // Cards
    'fg1': 3.50, 'fg2': 4.00, 'fg3': 6.50, 'fg4': 5.00, // Real vs Barca
  }
  
  return oddsData[selectionId] || 2.0
}