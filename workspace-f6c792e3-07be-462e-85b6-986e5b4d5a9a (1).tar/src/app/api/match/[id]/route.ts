import { NextRequest, NextResponse } from 'next/server'

interface MatchDetails {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  leagueFlag: string
  venue?: string
  attendance?: number
  kickoff?: string
  finishedAt?: string
  matchday?: string
  predictions: any[]
  odds: any
  markets: any[]
  events: any[]
  stats: any
}

const mockMatchDetails: Record<string, MatchDetails> = {
  '1': {
    id: '1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    status: 'live',
    minute: 67,
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    attendance: 55000,
    kickoff: '2024-03-10T20:00:00',
    matchday: '26',
    predictions: [
      {
        id: 'pred1',
        type: 'MATCH_WINNER',
        value: 'Manchester City',
        confidence: 75,
        reasoning: 'Strong home form and head-to-head advantage',
        tips: ['Home advantage', 'Attacking prowess', 'Key players available'],
        createdAt: '2024-03-09T10:30:00'
      }
    ],
    odds: {
      matchWinner: {
        homeWin: 2.10,
        draw: 3.40,
        awayWin: 3.80
      },
      overUnder: {
        '2.5': { over: 1.85, under: 1.95 },
        '3.5': { over: 1.65, under: 2.25 }
      }
    },
    markets: [
      {
        id: 'match-winner',
        type: 'MATCH_WINNER',
        name: 'Match Winner',
        selections: [
          { id: 'home-win', name: 'Manchester City', odds: 2.10 },
          { id: 'draw', name: 'Draw', odds: 3.40 },
          { id: 'away-win', name: 'Liverpool', odds: 3.80 }
        ]
      },
      {
        id: 'over-under-2.5',
        type: 'OVER_UNDER',
        name: 'Over/Under 2.5',
        selections: [
          { id: 'over', name: 'Over 2.5', odds: 1.85 },
          { id: 'under', name: 'Under 2.5', odds: 1.95 }
        ]
      },
      {
        id: 'both-teams-score',
        type: 'BOTH_TEAMS_SCORE',
        name: 'Both Teams Score',
        selections: [
          { id: 'yes', name: 'Yes', odds: 1.65 },
          { id: 'no', name: 'No', odds: 2.25 }
        ]
      }
    ],
    events: [
      {
        id: 'event1',
        type: 'GOAL',
        minute: 12,
        player: 'Erling Haaland',
        team: 'Manchester City',
        description: 'Opening goal from close range after brilliant team play'
      },
      {
        id: 'event2',
        type: 'YELLOW_CARD',
        minute: 34,
        player: 'Fabinho',
        team: 'Manchester City',
        description: 'Professional foul breaking up Liverpool attack'
      },
      {
        id: 'event3',
        type: 'GOAL',
        minute: 55,
        player: 'Mohamed Salah',
        team: 'Liverpool',
        description: 'Penalty after handball in the box'
      }
    ],
    stats: {
      homeTeam: {
        possession: 62,
        shots: 14,
        shotsOnTarget: 6,
        corners: 7,
        fouls: 8,
        yellowCards: 1,
        redCards: 0,
        xG: 3.2,
        xGA: 0.8
      },
      awayTeam: {
        possession: 38,
        shots: 8,
        shotsOnTarget: 3,
        corners: 3,
        fouls: 12,
        yellowCards: 2,
        redCards: 0,
        xG: 1.1,
        xGA: 3.2
      }
    }
  }
}

export async function GET(request: NextRequest, { params }: { params: { id?: string } }) {
  const matchId = params.id
  
  if (!matchId) {
    return NextResponse.json(
      { success: false, error: 'Match ID is required' },
      { status: 400 }
    )
  }

  try {
    const match = mockMatchDetails[matchId]
    
    if (!match) {
      return NextResponse.json(
        { success: false, error: 'Match not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      match,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Match details API error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch match details',
        message: error.message 
      },
      { status: 500 }
    )
  }
}