import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')

  if (!id) {
    return NextResponse.json(
      { 
        success: false, 
        error: 'Match ID is required' 
      },
      { status: 400 }
    )
  }

  try {
    const match = await db.match.findUnique({
      where: { id },
      include: {
        homeTeamStats: true,
        awayTeamStats: true,
        league: {
          select: {
            name: true,
            country: true,
            flag: true
          }
        },
        markets: {
          include: {
            overUnder: true
          }
        },
        predictions: {
          include: {
            factors: true
          }
        }
      }
    })

    if (!match) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Match not found' 
        },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      match,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to fetch match details:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch match details' 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, homeScore, awayScore, status, minute, homeTeamStats, awayTeamStats } = body

    if (!id) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Match ID is required' 
        },
        { status: 400 }
      )
    }

    const updatedMatch = await db.match.update({
      where: { id },
      data: {
        homeScore,
        awayScore,
        status,
        minute,
        homeTeamStats: homeTeamStats ? {
          upsert: {
            create: homeTeamStats
          }
        } : undefined,
        awayTeamStats: awayTeamStats ? {
          upsert: {
            create: awayTeamStats
          }
        } : undefined
      }
    })

    return NextResponse.json({
      success: true,
      match: updatedMatch,
      action: 'updated',
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to update match:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to update match' 
      },
      { status: 500 }
    )
  }
}