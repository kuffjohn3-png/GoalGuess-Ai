import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const matchId = searchParams.get('matchId')

  if (!matchId) {
    return NextResponse.json(
      { 
        success: false, 
        error: 'Match ID is required' 
      },
      { status: 400 }
    )
  }

  try {
    const markets = await db.market.findMany({
      where: { matchId },
      include: {
        overUnder: true
      }
    })

    const match = await db.match.findUnique({
      where: { id: matchId },
      include: {
        homeTeamStats: true,
        awayTeamStats: true,
        markets: {
          include: {
            overUnder: true
          }
        }
      }
    })

    if (!match) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Match not found' 
        },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      match,
      markets,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to fetch match markets:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch match markets' 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matchId, marketType, homeOdds, awayOdds, drawOdds, overOdds, underOdds, total, line } = body

    if (!matchId || !marketType) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Match ID and market type are required' 
        },
        { status: 400 }
      )
    }

    // Check if market already exists
    const existingMarket = await db.market.findFirst({
      where: { 
        matchId, 
        marketType 
      }
    })

    if (existingMarket) {
      // Update existing market
      const updatedMarket = await db.market.update({
        where: { id: existingMarket.id },
        data: {
          homeOdds,
          awayOdds,
          drawOdds,
          overOdds,
          underOdds,
          total,
          line
        }
      })

      return NextResponse.json({
        success: true,
        market: updatedMarket,
        action: 'updated',
        timestamp: new Date().toISOString()
      })
    }

    // Create new market
    const newMarket = await db.market.create({
      data: {
        matchId,
        marketType,
        homeOdds,
        awayOdds,
        drawOdds,
        overOdds,
        overUnder: total && line ? {
          create: {
            total,
            line,
            selected: true
          }
        } : undefined,
        selected: false
      }
    })

    return NextResponse.json({
      success: true,
      market: newMarket,
      action: 'created',
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to update markets:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to update markets' 
      },
      { status: 500 }
    )
  }
}