import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  const league = searchParams.get('league')
  const status = searchParams.get('status')
  const limit = parseInt(searchParams.get('limit') || '10')

  try {
    let whereClause: any = {}
    
    if (id) {
      whereClause.id = id
    }
    
    if (league) {
      whereClause.league = { contains: league, mode: 'insensitive' }
    }
    
    if (status) {
      whereClause.status = status
    }

    const matches = await db.match.findMany({
      where: whereClause,
      include: {
        homeTeamStats: true,
        awayTeamStats: true,
        league: {
          select: {
            name: true,
            country: true,
            flag: true
          }
        },
        markets: {
          include: {
            overUnder: true
          }
        }
      },
      orderBy: {
        kickoff: 'desc'
      },
      take: limit
    })

    return NextResponse.json({
      success: true,
      matches,
      filters: { id, league, status, limit },
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to fetch matches:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch matches' 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, homeTeam, awayTeam, kickoff, venue, league, homeOdds, awayOdds, drawOdds, overOdds, underOdds, markets } = body

    if (!id || !homeTeam || !awayTeam) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Missing required fields: id, homeTeam, awayTeam' 
        },
        { status: 400 }
      )
    }

    const match = await db.match.create({
      data: {
        homeTeam,
        awayTeam,
        kickoff: kickoff ? new Date(kickoff) : new Date(),
        venue,
        league,
        status: 'UPCOMING',
        homeScore: 0,
        awayScore: 0,
        homeTeamStats: {
          create: {
            possession: 0,
            shots: 0,
            shotsOnTarget: 0,
            corners: 0,
            fouls: 0,
            yellowCards: 0,
            redCards: 0
          }
        },
        awayTeamStats: {
          create: {
            possession: 0,
            shots: 0,
            shotsOnTarget: 0,
            corners: 0,
            fouls: 0,
            yellowCards: 0,
            redCards: 0
          }
        },
        markets: {
          create: markets || []
        }
      }
    })

    return NextResponse.json({
      success: true,
      match,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    console.error('Failed to create match:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to create match' 
      },
      { status: 500 }
    )
  }
}