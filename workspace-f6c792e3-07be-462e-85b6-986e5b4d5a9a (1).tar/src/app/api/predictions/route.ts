import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const homeTeam = searchParams.get('homeTeam')
    const awayTeam = searchParams.get('awayTeam')
    const league = searchParams.get('league')

    if (!homeTeam || !awayTeam) {
      return NextResponse.json(
        { error: 'Home team and away team are required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const prompt = `As a professional football analyst, provide a detailed prediction for the upcoming match between ${homeTeam} and ${awayTeam} in ${league || 'their league'}.

Please analyze and provide:
1. The likely winner (or draw)
2. Confidence percentage (0-100%)
3. 3-4 key betting tips or insights
4. Brief reasoning for your prediction

Consider factors like:
- Current form and recent results
- Head-to-head record
- Team strengths and weaknesses
- Key player availability
- Home advantage
- Tactical matchups

Format your response as JSON with the following structure:
{
  "winner": "Team Name or Draw",
  "confidence": 75,
  "tips": ["Tip 1", "Tip 2", "Tip 3"],
  "reasoning": "Brief explanation of the prediction"
}

Be realistic and base your analysis on actual football knowledge.`

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert football analyst with deep knowledge of teams, players, and tactical analysis. Provide accurate, well-reasoned predictions based on current football data and trends.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 500
    })

    const responseText = completion.choices[0]?.message?.content
    
    if (!responseText) {
      throw new Error('No response from AI model')
    }

    // Try to parse the JSON response
    let prediction
    try {
      prediction = JSON.parse(responseText)
    } catch (parseError) {
      // If parsing fails, create a structured response from the text
      prediction = {
        winner: "Analysis pending",
        confidence: 50,
        tips: ["Analyzing match data", "Checking team form", "Reviewing head-to-head"],
        reasoning: responseText
      }
    }

    return NextResponse.json({
      success: true,
      prediction,
      timestamp: new Date().toISOString()
    })

  } catch (error: any) {
    console.error('Prediction API error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to generate prediction',
        message: error.message,
        success: false 
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { matches } = body

    if (!matches || !Array.isArray(matches)) {
      return NextResponse.json(
        { error: 'Matches array is required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()
    const predictions = []

    for (const match of matches) {
      const prompt = `Provide a quick prediction for ${match.homeTeam} vs ${match.awayTeam} in ${match.league}.

Return JSON with:
{
  "winner": "Team Name or Draw",
  "confidence": 0-100,
  "tips": ["2-3 short tips"]
}`

      try {
        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are a football analyst. Provide concise, accurate predictions.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 200
        })

        const responseText = completion.choices[0]?.message?.content
        
        let prediction
        try {
          prediction = JSON.parse(responseText || '{}')
        } catch {
          prediction = {
            winner: "Analysis pending",
            confidence: 50,
            tips: ["Processing analysis"]
          }
        }

        predictions.push({
          matchId: match.id,
          prediction
        })
      } catch (error) {
        predictions.push({
          matchId: match.id,
          prediction: {
            winner: "Analysis failed",
            confidence: 0,
            tips: ["Unable to generate prediction"]
          }
        })
      }
    }

    return NextResponse.json({
      success: true,
      predictions,
      timestamp: new Date().toISOString()
    })

  } catch (error: any) {
    console.error('Batch prediction error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to generate batch predictions',
        message: error.message,
        success: false 
      },
      { status: 500 }
    )
  }
}