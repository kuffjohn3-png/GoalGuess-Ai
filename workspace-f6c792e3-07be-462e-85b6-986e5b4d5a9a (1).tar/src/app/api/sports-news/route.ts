import { NextResponse } from 'next/server'

interface NewsArticle {
  id: string
  title: string
  summary: string
  content: string
  category: string
  source: string
  author: string
  publishedAt: string
  imageUrl?: string
  tags: string[]
  priority: 'breaking' | 'featured' | 'normal'
  relatedTeams?: string[]
  relatedLeagues?: string[]
}

const mockNews: NewsArticle[] = [
  {
    id: '1',
    title: 'Champions League Draw: Manchester City vs Real Madrid Confirmed for Quarter-Finals',
    summary: 'The heavyweight clash between two European giants is set to be one of the most anticipated matches of the season.',
    content: 'UEFA has confirmed the Champions League quarter-final draw, with Manchester City set to face Real Madrid in what promises to be a thrilling encounter. Both teams have been in exceptional form, with City dominating the Premier League and Real Madrid leading La Liga. The first leg will be played at the Etihad Stadium on April 9th, with the return leg at the Bernabéu on April 17th. Fans can expect a tactical battle between Pep Guardiola and Carlo Ancelotti, two of the most decorated managers in modern football.',
    category: 'Champions League',
    source: 'UEFA Official',
    author: 'Sports Correspondent',
    publishedAt: new Date(Date.now() - 3600000).toISOString(),
    imageUrl: '/news/champions-league-draw.jpg',
    tags: ['Champions League', 'Manchester City', 'Real Madrid', 'Draw'],
    priority: 'breaking',
    relatedTeams: ['Manchester City', 'Real Madrid'],
    relatedLeagues: ['Champions League']
  },
  {
    id: '2',
    title: 'Premier League Title Race: Liverpool Cut Gap to Arsenal to Two Points',
    summary: 'Liverpool secured a crucial 2-0 victory over Manchester City, closing the gap on league leaders Arsenal.',
    content: 'Liverpool delivered a masterclass performance at Anfield, defeating Manchester City 2-0 with goals from Mohamed Salah and Darwin Núñez. The result moves Jurgen Klopp\'s side within two points of Arsenal, who dropped points in a surprise draw against Nottingham Forest. The title race is now heating up with just eight matches remaining. City remain in third place, six points behind the leaders, but with a game in hand.',
    category: 'Premier League',
    source: 'BBC Sport',
    author: 'Football Analyst',
    publishedAt: new Date(Date.now() - 7200000).toISOString(),
    imageUrl: '/news/liverpool-victory.jpg',
    tags: ['Premier League', 'Liverpool', 'Manchester City', 'Title Race'],
    priority: 'featured',
    relatedTeams: ['Liverpool', 'Manchester City', 'Arsenal'],
    relatedLeagues: ['Premier League']
  },
  {
    id: '3',
    title: 'Kylian Mbappé Decision: Real Madrid Move Imminent',
    summary: 'Sources close to the situation indicate that Kylian Mbappé has made his final decision to join Real Madrid this summer.',
    content: 'After months of speculation, Kylian Mbappé appears to have chosen his next destination. Multiple sources confirm that the PSG superstar has informed Paris Saint-Germain of his intention to leave when his contract expires in June. Real Madrid have been pursuing the French forward for several years and are now in pole position to secure his signature. The deal is expected to be one of the largest in football history, with a reported salary of €15 million per year over five years.',
    category: 'Transfer News',
    source: 'Transfer Expert',
    author: 'Transfer Correspondent',
    publishedAt: new Date(Date.now() - 10800000).toISOString(),
    imageUrl: '/news/mbappe-real-madrid.jpg',
    tags: ['Transfer', 'Kylian Mbappé', 'Real Madrid', 'PSG'],
    priority: 'breaking',
    relatedTeams: ['Real Madrid', 'PSG'],
    relatedLeagues: ['La Liga', 'Ligue 1']
  },
  {
    id: '4',
    title: 'Bundesliga Surprise: Bayer Leverkusen Continue Unbeaten Run',
    summary: 'Xabi Alonso\'s side extended their unbeaten run to 25 matches with a convincing 3-0 win over Union Berlin.',
    content: 'Bayer Leverkusen continue to defy expectations in the Bundesliga, extending their unbeaten run to 25 matches after a dominant 3-0 victory over Union Berlin. Under the guidance of Xabi Alonso, the Werkself has transformed from potential relegation candidates to genuine title contenders. Their attacking style, combined with defensive solidity, has seen them score 73 goals while conceding only 19. Bayern Munich now face their biggest challenge in years as Leverkusen sit 2 points clear at the top of the table.',
    category: 'Bundesliga',
    source: 'Bundesliga Official',
    author: 'German Football Expert',
    publishedAt: new Date(Date.now() - 14400000).toISOString(),
    imageUrl: '/news/leverkusen-celebration.jpg',
    tags: ['Bundesliga', 'Bayer Leverkusen', 'Xabi Alonso', 'Unbeaten Run'],
    priority: 'featured',
    relatedTeams: ['Bayer Leverkusen', 'Union Berlin', 'Bayern Munich'],
    relatedLeagues: ['Bundesliga']
  },
  {
    id: '5',
    title: 'Serie A Scandal: Juventus Points Deduction Confirmed',
    summary: 'Juventus have been deducted 10 points for financial irregularities, significantly impacting their Champions League qualification hopes.',
    content: 'The Italian Football Federation has confirmed a 10-point deduction for Juventus following an investigation into financial irregularities and false accounting. This is the second major penalty for the Old Lady this season, compounding their struggles on the pitch. The deduction drops Juventus from third to seventh place in Serie A, potentially jeopardizing their Champions League qualification for next season. The club has announced they will appeal the decision, but the impact on their season is already being felt.',
    category: 'Serie A',
    source: 'Gazzetta dello Sport',
    author: 'Italian Football Correspondent',
    publishedAt: new Date(Date.now() - 18000000).toISOString(),
    imageUrl: '/news/juventus-protest.jpg',
    tags: ['Serie A', 'Juventus', 'Points Deduction', 'Financial Fair Play'],
    priority: 'normal',
    relatedTeams: ['Juventus'],
    relatedLeagues: ['Serie A']
  },
  {
    id: '6',
    title: 'La Liga Title Race: Three-Way Battle Intensifies',
    summary: 'Real Madrid, Barcelona, and Girona are separated by just 5 points with 10 matches remaining in an unprecedented title race.',
    content: 'La Liga is witnessing its most competitive title race in years, with Real Madrid leading on 60 points, followed by Barcelona on 58, and surprise package Girona on 55. The remaining fixtures will be crucial as all three teams still have to face each other. Real Madrid have the advantage of head-to-head record, but Barcelona\'s recent form has been impressive. Girona, under Michel\'s guidance, continue to defy expectations and could be the dark horses in this three-horse race.',
    category: 'La Liga',
    source: 'Marca',
    author: 'Spanish Football Expert',
    publishedAt: new Date(Date.now() - 21600000).toISOString(),
    imageUrl: '/news/la-liga-race.jpg',
    tags: ['La Liga', 'Real Madrid', 'Barcelona', 'Girona', 'Title Race'],
    priority: 'featured',
    relatedTeams: ['Real Madrid', 'Barcelona', 'Girona'],
    relatedLeagues: ['La Liga']
  },
  {
    id: '7',
    title: 'Erling Haaland Injury Concern: Man City Star Faces Race Against Time',
    summary: 'Manchester City striker Erling Haaland is facing a race against time to be fit for the crucial Champions League quarter-final.',
    content: 'Manchester City have confirmed that Erling Haaland is receiving intensive treatment for a muscle injury sustained in training. The Norwegian striker, who has scored 27 goals this season, is rated as 50-50 for the first leg of the Champions League quarter-final against Real Madrid. City medical staff are working around the clock to get him fit, but manager Pep Guardiola may have to consider alternative options. Julian Álvarez is ready to step in if Haaland fails to recover in time.',
    category: 'Injury News',
    source: 'Sky Sports',
    author: 'Medical Correspondent',
    publishedAt: new Date(Date.now() - 25200000).toISOString(),
    imageUrl: '/news/haaland-injury.jpg',
    tags: ['Injury', 'Erling Haaland', 'Manchester City', 'Champions League'],
    priority: 'normal',
    relatedTeams: ['Manchester City', 'Real Madrid'],
    relatedLeagues: ['Premier League', 'Champions League']
  },
  {
    id: '8',
    title: 'Ligue 1 Breakthrough: Lille Challenge PSG\'s Dominance',
    summary: 'Lille have emerged as genuine contenders to PSG\'s Ligue 1 dominance with impressive tactical displays.',
    content: 'While PSG continue to lead Ligue 1, Lille have established themselves as the most credible challengers to Parisian dominance. Under Paulo Fonseca, Lille have developed a tactical system that has frustrated bigger teams and produced consistent results. Their defensive solidity, combined with rapid counter-attacks, has seen them accumulate 56 points, just 8 behind leaders PSG. With both teams still to play, a potential title showdown could be on the cards.',
    category: 'Ligue 1',
    source: 'L\'Equipe',
    author: 'French Football Analyst',
    publishedAt: new Date(Date.now() - 28800000).toISOString(),
    imageUrl: '/news/lille-celebration.jpg',
    tags: ['Ligue 1', 'Lille', 'PSG', 'Title Challenge'],
    priority: 'normal',
    relatedTeams: ['Lille', 'PSG'],
    relatedLeagues: ['Ligue 1']
  }
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  const team = searchParams.get('team')
  const league = searchParams.get('league')
  const priority = searchParams.get('priority')
  const limit = parseInt(searchParams.get('limit') || '10')

  try {
    let filteredNews = [...mockNews]

    // Filter by category
    if (category) {
      filteredNews = filteredNews.filter(article => 
        article.category.toLowerCase().includes(category.toLowerCase())
      )
    }

    // Filter by team
    if (team) {
      filteredNews = filteredNews.filter(article => 
        article.relatedTeams?.some(t => t.toLowerCase().includes(team.toLowerCase()))
      )
    }

    // Filter by league
    if (league) {
      filteredNews = filteredNews.filter(article => 
        article.relatedLeagues?.some(l => l.toLowerCase().includes(league.toLowerCase()))
      )
    }

    // Filter by priority
    if (priority) {
      filteredNews = filteredNews.filter(article => article.priority === priority)
    }

    // Sort by priority and date
    filteredNews.sort((a, b) => {
      const priorityOrder = { breaking: 3, featured: 2, normal: 1 }
      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority]
      if (priorityDiff !== 0) return priorityDiff
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    })

    // Limit results
    const limitedNews = filteredNews.slice(0, limit)

    return NextResponse.json({
      success: true,
      articles: limitedNews,
      total: filteredNews.length,
      categories: ['Champions League', 'Premier League', 'La Liga', 'Bundesliga', 'Serie A', 'Ligue 1', 'Transfer News', 'Injury News'],
      filters: {
        category,
        team,
        league,
        priority,
        limit
      },
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to fetch sports news' 
      },
      { status: 500 }
    )
  }
}