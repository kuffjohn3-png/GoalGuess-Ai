import { NextResponse } from 'next/server'

const mockTopScorers = [
  { rank: 1, name: 'Erling Haaland', team: 'Manchester City', league: 'Premier League', goals: 27, assists: 5, matches: 25, shots: 85, shotsOnTarget: 42 },
  { rank: 2, name: 'Kylian Mbappé', team: 'PSG', league: 'Ligue 1', goals: 24, assists: 7, matches: 23, shots: 78, shotsOnTarget: 45 },
  { rank: 3, name: 'Harry Kane', team: 'Bayern Munich', league: 'Bundesliga', goals: 22, assists: 8, matches: 24, shots: 72, shotsOnTarget: 38 },
  { rank: 4, name: 'Mohamed Salah', team: 'Liverpool', league: 'Premier League', goals: 19, assists: 10, matches: 26, shots: 88, shotsOnTarget: 41 },
  { rank: 5, name: 'Jude Bellingham', team: 'Real Madrid', league: 'La Liga', goals: 17, assists: 6, matches: 22, shots: 58, shotsOnTarget: 32 },
  { rank: 6, name: 'Serhou Guirassy', team: 'Stuttgart', league: 'Bundesliga', goals: 16, assists: 2, matches: 20, shots: 65, shotsOnTarget: 35 },
  { rank: 7, name: 'Victor Osimhen', team: 'Napoli', league: 'Serie A', goals: 15, assists: 3, matches: 21, shots: 70, shotsOnTarget: 36 },
  { rank: 8, name: 'Lautaro Martínez', team: 'Inter Milan', league: 'Serie A', goals: 14, assists: 5, matches: 23, shots: 62, shotsOnTarget: 33 },
  { rank: 9, name: 'Rasmus Højlund', team: 'Manchester United', league: 'Premier League', goals: 13, assists: 2, matches: 25, shots: 68, shotsOnTarget: 30 },
  { rank: 10, name: 'Robert Lewandowski', team: 'Barcelona', league: 'La Liga', goals: 12, assists: 4, matches: 22, shots: 55, shotsOnTarget: 29 }
]

const mockTeamStats = [
  { 
    team: 'Manchester City', 
    league: 'Premier League',
    played: 25, 
    won: 18, 
    drawn: 4, 
    lost: 3,
    goalsFor: 52,
    goalsAgainst: 24,
    cleanSheets: 8,
    yellowCards: 34,
    redCards: 2,
    possession: 62.5,
    passAccuracy: 89.2
  },
  { 
    team: 'Real Madrid', 
    league: 'La Liga',
    played: 24, 
    won: 19, 
    drawn: 3, 
    lost: 2,
    goalsFor: 46,
    goalsAgainst: 16,
    cleanSheets: 12,
    yellowCards: 28,
    redCards: 1,
    possession: 58.3,
    passAccuracy: 87.8
  },
  { 
    team: 'Bayern Munich', 
    league: 'Bundesliga',
    played: 24, 
    won: 16, 
    drawn: 3, 
    lost: 5,
    goalsFor: 58,
    goalsAgainst: 29,
    cleanSheets: 6,
    yellowCards: 41,
    redCards: 3,
    possession: 64.1,
    passAccuracy: 88.5
  }
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get('type')
  const league = searchParams.get('league')

  try {
    switch (type) {
      case 'topscorers':
        const filteredScorers = league 
          ? mockTopScorers.filter(scorer => scorer.league.toLowerCase().includes(league.toLowerCase()))
          : mockTopScorers
        return NextResponse.json({
          success: true,
          topScorers: filteredScorers,
          timestamp: new Date().toISOString()
        })

      case 'teams':
        const filteredTeams = league
          ? mockTeamStats.filter(team => team.league.toLowerCase().includes(league.toLowerCase()))
          : mockTeamStats
        return NextResponse.json({
          success: true,
          teamStats: filteredTeams,
          timestamp: new Date().toISOString()
        })

      default:
        return NextResponse.json({
          success: true,
          topScorers: mockTopScorers,
          teamStats: mockTeamStats,
          timestamp: new Date().toISOString()
        })
    }
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch statistics' },
      { status: 500 }
    )
  }
}