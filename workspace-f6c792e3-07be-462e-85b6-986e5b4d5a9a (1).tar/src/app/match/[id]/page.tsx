'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Trophy, 
  TrendingUp, 
  Users, 
  Calendar,
  Clock,
  MapPin,
  Play,
  BarChart3,
  X,
  Home as HomeIcon
} from 'lucide-react'

interface Match {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  leagueFlag: string
  venue?: string
  attendance?: number
  kickoff?: string
  finishedAt?: string
  matchday?: string
}

export default function MatchDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const [match, setMatch] = useState<Match | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params.id) {
      fetchMatchDetails(params.id)
    }
  }, [params.id])

  const fetchMatchDetails = async (matchId: string) => {
    try {
      setLoading(true)
      const response = await fetch(`/api/match/${matchId}`)
      const data = await response.json()
      
      if (data.success) {
        setMatch(data.match)
      }
    } catch (error) {
      console.error('Failed to fetch match details:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string, minute?: number) => {
    switch (status) {
      case 'live':
        return (
          <Badge variant="destructive" className="animate-pulse">
            <Play className="w-3 h-3 mr-1" />
            LIVE {minute && `${minute}'`}
          </Badge>
        )
      case 'finished':
        return <Badge variant="secondary">FT</Badge>
      case 'upcoming':
        return <Badge variant="outline">UPCOMING</Badge>
      default:
        return null
    }
  }

  const formatDateTime = (dateTime: string) => {
    const date = new Date(dateTime)
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!match) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Match not found</h2>
          <Button onClick={() => router.back()}>Go Back</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.back()}>
              <X className="w-4 h-4" />
            </Button>
            <h1 className="text-xl font-bold">Match Details</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Match Overview */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-lg">{match.homeTeam}</span>
                  <span className="text-2xl font-bold mx-4">{match.homeScore}</span>
                  <span className="text-lg">{match.awayTeam}</span>
                </CardTitle>
                <div className="flex items-center gap-2">
                  {getStatusBadge(match.status, match.minute)}
                  <span className="text-sm text-muted-foreground">
                    {match.league} • {formatDateTime(match.kickoff || '')}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="grid grid-cols-3 gap-8 mb-6">
                  <div className="text-center">
                    <Avatar className="w-16 h-16 mx-auto mb-2">
                      <AvatarFallback className="text-lg font-bold">
                        {match.homeTeam.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-sm font-medium">{match.homeTeam}</div>
                    <div className="text-xs text-muted-foreground">Home</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{match.homeScore}</div>
                    {match.status === 'live' && (
                      <div className="text-sm text-muted-foreground animate-pulse">
                        {match.minute && `${match.minute}'`}
                      </div>
                    )}
                  </div>
                  <div className="text-center">
                    <Avatar className="w-16 h-16 mx-auto mb-2">
                      <AvatarFallback className="text-lg font-bold">
                        {match.awayTeam.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-sm font-medium">{match.awayTeam}</div>
                    <div className="text-xs text-muted-foreground">Away</div>
                  </div>
                </div>

                {/* Match Info */}
                <div className="space-y-4">
                  <div className="flex items-center gap-4 text-sm">
                    <MapPin className="w-4 h-4" />
                    <span>{match.venue}</span>
                    {match.attendance && (
                      <>
                        <Separator orientation="vertical" className="h-4 mx-2" />
                        <Users className="w-4 h-4" />
                        {match.attendance.toLocaleString()}
                      </>
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <Calendar className="w-4 h-4" />
                    <span>Matchday {match.matchday}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <Clock className="w-4 h-4" />
                    <span>{formatDateTime(match.kickoff || '')}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Match Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <Badge variant="outline" className="mb-2">
                      {match.status.toUpperCase()}
                    </Badge>
                    <div className="text-2xl font-bold">
                      {match.homeScore} - {match.awayScore}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}