'use client'

import { useState, useEffect, useRef } from 'react'
import dynamic from 'next/dynamic'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trophy, 
  TrendingUp, 
  Users, 
  Calendar,
  Clock,
  Flag,
  Target,
  Zap,
  Shield,
  Star,
  ChevronRight,
  Play,
  Pause,
  RefreshCw,
  Soccer,
  BarChart3,
  MapPin,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Wifi,
  WifiOff,
  Bell,
  History,
  CalendarDays,
  TrendingDown,
  Home as HomeIcon,
  User,
  Timer,
  Tv,
  Award,
  TargetIcon,
  Newspaper,
  Filter,
  Search,
  Menu,
  X,
  ArrowUp,
  MessageSquare,
  Share2,
  Bookmark
} from 'lucide-react'

interface NewsArticle {
  id: string
  title: string
  summary: string
  content: string
  category: string
  source: string
  author: string
  publishedAt: string
  imageUrl?: string
  tags: string[]
  priority: 'breaking' | 'featured' | 'normal'
  relatedTeams?: string[]
  relatedLeagues?: string[]
}

interface Match {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  leagueFlag: string
  homeLogo?: string
  awayLogo?: string
  venue?: string
  attendance?: number
  prediction?: {
    winner: string
    confidence: number
    tips: string[]
    reasoning?: string
  }
  homeTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  awayTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  lastUpdate?: Date
}

interface Fixture {
  id: string
  homeTeam: string
  awayTeam: string
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  broadcast: string
  referee: string
}

interface PreviousGame {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  attendance: number
  homeTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  awayTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  goalscorers: Array<{
    player: string
    team: string
    minute: number
    type: string
  }>
  manOfTheMatch: string
}

interface HeadToHead {
  team1: string
  team2: string
  totalMatches: number
  team1Wins: number
  team2Wins: number
  draws: number
  team1Goals: number
  team2Goals: number
  last5Matches: Array<{
    date: string
    homeTeam: string
    awayTeam: string
    homeScore: number
    awayScore: number
    result: string
  }>
}

interface TeamForm {
  opponent: string
  result: string
  score: string
  home: boolean
}

const initialMatches: Match[] = [
  {
    id: '1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    status: 'live',
    minute: 67,
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    attendance: 55000,
    homeTeamStats: {
      possession: 62,
      shots: 14,
      shotsOnTarget: 6,
      corners: 7,
      fouls: 8,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 38,
      shots: 8,
      shotsOnTarget: 3,
      corners: 3,
      fouls: 12,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '2',
    homeTeam: 'Real Madrid',
    awayTeam: 'Barcelona',
    homeScore: 0,
    awayScore: 0,
    status: 'live',
    minute: 34,
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Santiago Bernabéu',
    attendance: 80000,
    homeTeamStats: {
      possession: 55,
      shots: 9,
      shotsOnTarget: 2,
      corners: 4,
      fouls: 6,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 45,
      shots: 7,
      shotsOnTarget: 2,
      corners: 2,
      fouls: 9,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '3',
    homeTeam: 'Bayern Munich',
    awayTeam: 'Borussia Dortmund',
    homeScore: 3,
    awayScore: 2,
    status: 'finished',
    league: 'Bundesliga',
    leagueFlag: '🇩🇪',
    venue: 'Allianz Arena',
    attendance: 75000,
    homeTeamStats: {
      possession: 58,
      shots: 18,
      shotsOnTarget: 8,
      corners: 9,
      fouls: 10,
      yellowCards: 2,
      redCards: 0
    },
    awayTeamStats: {
      possession: 42,
      shots: 12,
      shotsOnTarget: 5,
      corners: 4,
      fouls: 14,
      yellowCards: 3,
      redCards: 1
    }
  },
  {
    id: '4',
    homeTeam: 'PSG',
    awayTeam: 'Marseille',
    homeScore: 0,
    awayScore: 0,
    status: 'upcoming',
    league: 'Ligue 1',
    leagueFlag: '🇫🇷',
    venue: 'Parc des Princes',
    attendance: 0
  }
]

export default function Home() {
  const [matches, setMatches] = useState<Match[]>(initialMatches)
  const [fixtures, setFixtures] = useState<Fixture[]>([])
  const [previousGames, setPreviousGames] = useState<PreviousGame[]>([])
  const [headToHead, setHeadToHead] = useState<HeadToHead[]>([])
  const [teamForms, setTeamForms] = useState<Record<string, TeamForm[]>>({})
  const [sportsNews, setSportsNews] = useState<NewsArticle[]>([])
  const [leagues, setLeagues] = useState<any[]>([])
  const [topScorers, setTopScorers] = useState<any[]>([])
  const [teamStats, setTeamStats] = useState<any[]>([])
  const [selectedTab, setSelectedTab] = useState('livescore')
  const [selectedLeague, setSelectedLeague] = useState('all')
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [loading, setLoading] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [notifications, setNotifications] = useState<string[]>([])
  const [showBottomNav, setShowBottomNav] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const [isTablet, setIsTablet] = useState(false)
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [showMatchDetails, setShowMatchDetails] = useState(false)
  const socketRef = useRef<any>(null)

  useEffect(() => {
    fetchLeagues()
    fetchStats()
    fetchFixtures()
    fetchPreviousGames()
    fetchHeadToHead()
    fetchTeamForms()
    fetchSportsNews()
    connectWebSocket()
    
    // Detect device type
    const detectDevice = () => {
      const width = window.innerWidth
      setIsMobile(width < 768)
      setIsTablet(width >= 768 && width < 1024)
      setShowBottomNav(width < 1024)
    }
    
    detectDevice()
    window.addEventListener('resize', detectDevice)
    
    return () => {
      window.removeEventListener('resize', detectDevice)
    }
  }, [])

  const fetchSportsNews = async () => {
  try {
    const response = await fetch('/api/sports-news?limit=6')
    const data = await response.json()
    if (data.success) {
      setSportsNews(data.articles || [])
    }
  } catch (error) {
    console.error('Failed to fetch sports news:', error)
  }
}

const connectWebSocket = () => {
    try {
      import('socket.io-client').then(({ io }) => {
        socketRef.current = io('/?XTransformPort=3002')
        
        socketRef.current.on('connect', () => {
          console.log('Connected to WebSocket service')
          setIsConnected(true)
        })
        
        socketRef.current.on('disconnect', () => {
          console.log('Disconnected from WebSocket service')
          setIsConnected(false)
        })
        
        socketRef.current.on('matchUpdate', (updatedMatches: Match[]) => {
          setMatches(prevMatches => {
            const newMatches = prevMatches.map(match => {
              const updatedMatch = updatedMatches.find((um: Match) => um.id === match.id)
              return updatedMatch || match
            })
            return newMatches
          })
          setLastUpdate(new Date())
        })
        
        socketRef.current.on('goal', (data: any) => {
          const notification = `⚽ GOAL! ${data.team} scored! ${data.score} (${data.minute}')`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
        
        socketRef.current.on('matchFinished', (data: any) => {
          const notification = `🏁 Match finished: ${data.finalScore} - Winner: ${data.winner}`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
      })
    } catch (error) {
      console.error('Failed to connect to WebSocket:', error)
      setIsConnected(false)
    }
  }

  const fetchFixtures = async () => {
    try {
      const response = await fetch('/api/fixtures')
      const data = await response.json()
      if (data.success) {
        setFixtures(data.fixtures || [])
      }
    } catch (error) {
      console.error('Failed to fetch fixtures:', error)
    }
  }

  const fetchPreviousGames = async () => {
    try {
      const response = await fetch('/api/previous-games?type=recent')
      const data = await response.json()
      if (data.success) {
        setPreviousGames(data.games || [])
      }
    } catch (error) {
      console.error('Failed to fetch previous games:', error)
    }
  }

  const fetchHeadToHead = async () => {
    try {
      const response = await fetch('/api/previous-games?type=head2head')
      const data = await response.json()
      if (data.success) {
        setHeadToHead(data.headToHead || [])
      }
    } catch (error) {
      console.error('Failed to fetch head-to-head:', error)
    }
  }

  const fetchTeamForms = async () => {
    try {
      const response = await fetch('/api/previous-games?type=form')
      const data = await response.json()
      if (data.success) {
        setTeamForms(data.teamForms || {})
      }
    } catch (error) {
      console.error('Failed to fetch team forms:', error)
    }
  }

  const fetchLeagues = async () => {
    try {
      const response = await fetch('/api/leagues')
      const data = await response.json()
      if (data.success) {
        setLeagues(data.leagues)
      }
    } catch (error) {
      console.error('Failed to fetch leagues:', error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats')
      const data = await response.json()
      if (data.success) {
        setTopScorers(data.topScorers || [])
        setTeamStats(data.teamStats || [])
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const fetchPrediction = async (match: Match) => {
    try {
      setLoading(true)
      const response = await fetch(
        `/api/predictions?homeTeam=${encodeURIComponent(match.homeTeam)}&awayTeam=${encodeURIComponent(match.awayTeam)}&league=${encodeURIComponent(match.league)}`
      )
      const data = await response.json()
      
      if (data.success && data.prediction) {
        setMatches(prev => prev.map(m => 
          m.id === match.id 
            ? { ...m, prediction: data.prediction }
            : m
        ))
      }
    } catch (error) {
      console.error('Failed to fetch prediction:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string, minute?: number) => {
    switch (status) {
      case 'live':
        return (
          <Badge variant="destructive" className="animate-pulse">
            <Play className="w-3 h-3 mr-1" />
            LIVE {minute && `${minute}'`}
          </Badge>
        )
      case 'finished':
        return <Badge variant="secondary">FT</Badge>
      case 'upcoming':
        return <Badge variant="outline">UPCOMING</Badge>
      default:
        return null
    }
  }

  const getResultBadge = (result: string) => {
    switch (result) {
      case 'W':
        return <Badge className="bg-green-500 text-white">W</Badge>
      case 'L':
        return <Badge className="bg-red-500 text-white">L</Badge>
      case 'D':
        return <Badge className="bg-yellow-500 text-white">D</Badge>
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today'
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow'
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    }
  }

  const NewsArticleCard = ({ article }: { article: NewsArticle }) => (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={article.priority === 'breaking' ? 'destructive' : article.priority === 'featured' ? 'default' : 'secondary'} className="text-xs">
                {article.priority.toUpperCase()}
              </Badge>
              <Badge variant="outline" className="text-xs">{article.category}</Badge>
            </div>
            <CardTitle className="text-lg line-clamp-2">{article.title}</CardTitle>
            <CardDescription className="text-sm line-clamp-2 mt-1">{article.summary}</CardDescription>
          </div>
          {article.imageUrl && (
            <div className="w-20 h-16 bg-muted rounded-lg flex-shrink-0">
              <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover rounded-lg" />
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-2">
            <Newspaper className="w-3 h-3" />
            <span>{article.source}</span>
          </div>
          <div className="flex items-center gap-2">
            <User className="w-3 h-3" />
            <span>{article.author}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-3 h-3" />
            <span>{new Date(article.publishedAt).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 mb-3">
          {article.tags.map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <MessageSquare className="w-4 h-4 mr-2" />
            Read More
          </Button>
          <Button variant="ghost" size="sm">
            <Share2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Bookmark className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  const MatchDetailsDialog = dynamic(() => import('@/components/MatchDetailsDialog'), {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-200"></div>
      </div>
    )
  })

  const handleMatchClick = (match: Match) => {
    setSelectedMatch(match)
    setShowMatchDetails(true)
  }

  const MatchCard = ({ match }: { match: Match }) => (
    <Card 
      className="hover:shadow-lg transition-shadow relative cursor-pointer"
      onClick={() => handleMatchClick(match)}
    >
      {match.status === 'live' && (
        <div className="absolute top-2 right-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
        </div>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{match.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{match.league}</span>
          </div>
          {getStatusBadge(match.status, match.minute)}
        </div>
        {match.venue && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            {match.venue}
            {match.attendance && match.attendance > 0 && (
              <>
                <Separator orientation="vertical" className="h-3" />
                <Users className="w-3 h-3" />
                {match.attendance.toLocaleString()}
              </>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-2xl font-bold text-center">
              {match.homeScore} - {match.awayScore}
            </div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.awayTeam}</h3>
          </div>
        </div>

        {match.status === 'live' && match.homeTeamStats && match.awayTeamStats && (
          <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-muted rounded-lg">
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.homeTeamStats.possession}%</span>
              </div>
              <Progress value={match.homeTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.homeTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.homeTeamStats.corners}</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.awayTeamStats.possession}%</span>
              </div>
              <Progress value={match.awayTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.awayTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.awayTeamStats.corners}</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="border-t pt-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-muted-foreground">AI Prediction</span>
            {match.prediction ? (
              <Badge variant="outline" className="text-xs">
                {match.prediction.confidence}% confidence
              </Badge>
            ) : (
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => fetchPrediction(match)}
                disabled={loading}
              >
                {loading ? 'Loading...' : 'Get AI Tip'}
              </Button>
            )}
          </div>
          {match.prediction && (
            <>
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{match.prediction.winner}</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {match.prediction.tips.map((tip, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tip}
                  </Badge>
                ))}
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )

  const FixtureCard = ({ fixture }: { fixture: Fixture }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{fixture.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{fixture.league}</span>
          </div>
          <Badge variant="outline">{formatDate(fixture.date)}</Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <CalendarDays className="w-3 h-3" />
          {fixture.date} at {fixture.time}
          <Separator orientation="vertical" className="h-3" />
          <MapPin className="w-3 h-3" />
          {fixture.venue}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{fixture.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{fixture.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-lg font-bold text-center text-muted-foreground">VS</div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{fixture.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{fixture.awayTeam}</h3>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-1">
            <Tv className="w-3 h-3" />
            <span className="truncate">{fixture.broadcast}</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="w-3 h-3" />
            <span className="truncate">{fixture.referee}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            <span>MD {fixture.matchday}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const PreviousGameCard = ({ game }: { game: PreviousGame }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{game.leagueFlag}</span>
            <div>
              <span className="text-sm font-medium">{game.league}</span>
              <div className="text-xs text-muted-foreground">{game.date} • {game.venue}</div>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs">FT</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Match Result Rectangle */}
        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3 flex-1">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="text-sm font-bold">{game.homeTeam.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h4 className="font-semibold text-sm">{game.homeTeam}</h4>
                <div className="text-xs text-muted-foreground">Home</div>
              </div>
            </div>
            <div className="px-4">
              <div className="text-2xl font-bold text-center">
                {game.homeScore} - {game.awayScore}
              </div>
            </div>
            <div className="flex items-center gap-3 flex-1 justify-end">
              <div className="flex-1 text-right">
                <h4 className="font-semibold text-sm">{game.awayTeam}</h4>
              </div>
              <Avatar className="w-10 h-10">
                <AvatarFallback className="text-sm font-bold">{game.awayTeam.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>

        {/* Match Statistics Rectangle */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-3">
            <h5 className="font-medium text-sm mb-2 text-blue-700 dark:text-blue-300">{game.homeTeam}</h5>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span>Possession</span>
                <span className="font-medium">{game.homeTeamStats.possession}%</span>
              </div>
              <Progress value={game.homeTeamStats.possession} className="h-1" />
              <div className="flex justify-between">
                <span>Shots</span>
                <span className="font-medium">{game.homeTeamStats.shots}</span>
              </div>
              <div className="flex justify-between">
                <span>xG</span>
                <span className="font-medium">{game.homeTeamStats.xG}</span>
              </div>
            </div>
          </div>
          <div className="bg-red-50 dark:bg-red-950/20 rounded-lg p-3">
            <h5 className="font-medium text-sm mb-2 text-red-700 dark:text-red-300">{game.awayTeam}</h5>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span>Possession</span>
                <span className="font-medium">{game.awayTeamStats.possession}%</span>
              </div>
              <Progress value={game.awayTeamStats.possession} className="h-1" />
              <div className="flex justify-between">
                <span>Shots</span>
                <span className="font-medium">{game.awayTeamStats.shots}</span>
              </div>
              <div className="flex justify-between">
                <span>xG</span>
                <span className="font-medium">{game.awayTeamStats.xG}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Key Events Rectangle */}
        <div className="bg-amber-50 dark:bg-amber-950/20 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <Award className="w-4 h-4 text-amber-600" />
            <h5 className="font-medium text-sm text-amber-700 dark:text-amber-300">Key Events</h5>
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs bg-white dark:bg-gray-800">
                Man of Match
              </Badge>
              <span className="text-sm font-medium">{game.manOfTheMatch}</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {game.goalscorers.slice(0, 3).map((scorer, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  ⚽ {scorer.player} {scorer.minute}'
                </Badge>
              ))}
              {game.goalscorers.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{game.goalscorers.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const TeamFormCard = ({ team, form }: { team: string, form: TeamForm[] }) => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{team}</CardTitle>
        <CardDescription>Last 6 games form</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Form Summary Rectangle */}
        <div className="bg-gradient-to-r from-green-50 to-red-50 dark:from-green-950/20 dark:to-red-950/20 rounded-lg p-4">
          <h4 className="font-medium text-sm mb-3 text-center">Form Summary</h4>
          <div className="flex gap-2 mb-3">
            {form.map((game, index) => (
              <div key={index} className="flex-1 text-center">
                {getResultBadge(game.result)}
                <div className="text-xs text-muted-foreground mt-1">
                  {game.home ? <Home className="w-3 h-3 mx-auto" /> : <MapPin className="w-3 h-3 mx-auto" />}
                </div>
                <div className="text-xs font-medium mt-1">{game.score}</div>
                <div className="text-xs text-muted-foreground truncate">{game.opponent.slice(0, 3)}</div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 pt-3 border-t text-xs">
            <div className="text-center">
              <div className="font-bold text-green-600">{form.filter(g => g.result === 'W').length}</div>
              <div className="text-muted-foreground">Wins</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-yellow-600">{form.filter(g => g.result === 'D').length}</div>
              <div className="text-muted-foreground">Draws</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-red-600">{form.filter(g => g.result === 'L').length}</div>
              <div className="text-muted-foreground">Losses</div>
            </div>
          </div>
        </div>

        {/* Performance Stats Rectangle */}
        <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-3">
          <h5 className="font-medium text-sm mb-2">Performance</h5>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="flex justify-between">
              <span>Points Earned</span>
              <span className="font-medium">{form.filter(g => g.result === 'W').length * 3 + form.filter(g => g.result === 'D').length}</span>
            </div>
            <div className="flex justify-between">
              <span>Win Rate</span>
              <span className="font-medium">{Math.round((form.filter(g => g.result === 'W').length / form.length) * 100)}%</span>
            </div>
            <div className="flex justify-between">
              <span>Goals For</span>
              <span className="font-medium">{form.reduce((sum, game) => sum + parseInt(game.score.split('-')[0]), 0)}</span>
            </div>
            <div className="flex justify-between">
              <span>Goals Against</span>
              <span className="font-medium">{form.reduce((sum, game) => sum + parseInt(game.score.split('-')[1]), 0)}</span>
            </div>
          </div>
        </div>

        {/* Recent Matches Rectangle */}
        <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-3">
          <h5 className="font-medium text-sm mb-2 text-blue-700 dark:text-blue-300">Recent Results</h5>
          <div className="space-y-1 text-xs">
            {form.slice(0, 3).map((game, index) => (
              <div key={index} className="flex items-center justify-between p-1 bg-white dark:bg-gray-800 rounded">
                <div className="flex items-center gap-2">
                  {getResultBadge(game.result)}
                  <span>{game.opponent}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="font-medium">{game.score}</span>
                  {game.home ? <Home className="w-3 h-3" /> : <MapPin className="w-3 h-3" />}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Trophy className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Football Live</h1>
                <p className="text-sm text-muted-foreground">AI-Powered Scores & Predictions</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                {isConnected ? (
                  <>
                    <Wifi className="w-4 h-4 text-green-500" />
                    <span className="text-green-500">Live</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-4 h-4 text-red-500" />
                    <span className="text-red-500">Offline</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                Last updated: {lastUpdate.toLocaleTimeString()}
              </div>
              <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
          
          {notifications.length > 0 && (
            <div className="mt-4 space-y-2">
              {notifications.map((notification, index) => (
                <div key={index} className="p-2 bg-primary/10 border border-primary/20 rounded-lg text-sm animate-pulse">
                  <Bell className="w-4 h-4 inline mr-2" />
                  {notification}
                </div>
              ))}
            </div>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <TabsList className="grid w-full sm:w-auto grid-cols-3 lg:grid-cols-6">
              <TabsTrigger value="livescore" className="flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Live
              </TabsTrigger>
              <TabsTrigger value="fixtures" className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4" />
                Fixtures
              </TabsTrigger>
              <TabsTrigger value="previous" className="flex items-center gap-2">
                <History className="w-4 h-4" />
                Results
              </TabsTrigger>
              <TabsTrigger value="stats" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Stats
              </TabsTrigger>
              <TabsTrigger value="head2head" className="flex items-center gap-2">
                <TargetIcon className="w-4 h-4" />
                H2H
              </TabsTrigger>
              <TabsTrigger value="predictions" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                AI Tips
              </TabsTrigger>
            </TabsList>
            
            <Select value={selectedLeague} onValueChange={setSelectedLeague}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by league" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Leagues</SelectItem>
                {leagues.map((league) => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.flag} {league.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="livescore" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {matches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fixtures" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {fixtures.map((fixture) => (
                <FixtureCard key={fixture.id} fixture={fixture} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="previous" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {previousGames.map((game) => (
                <PreviousGameCard key={game.id} game={game} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="head2head" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {headToHead.map((h2h, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TargetIcon className="w-5 h-5" />
                      {h2h.team1} vs {h2h.team2}
                    </CardTitle>
                    <CardDescription>Head-to-head record</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Overall Record Rectangle */}
                    <div className="bg-gradient-to-r from-blue-50 to-red-50 dark:from-blue-950/20 dark:to-red-950/20 rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-4 text-center">Overall Record</h4>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">{h2h.team1Wins}</div>
                          <div className="text-sm text-muted-foreground">{h2h.team1}</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-yellow-600">{h2h.draws}</div>
                          <div className="text-sm text-muted-foreground">Draws</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-red-600">{h2h.team2Wins}</div>
                          <div className="text-sm text-muted-foreground">{h2h.team2}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                        <div className="text-center">
                          <div className="text-lg font-semibold">{h2h.team1Goals}</div>
                          <div className="text-xs text-muted-foreground">Goals Scored</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold">{h2h.team2Goals}</div>
                          <div className="text-xs text-muted-foreground">Goals Scored</div>
                        </div>
                      </div>
                    </div>

                    {/* Recent Matches Rectangle */}
                    <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-4">
                      <h4 className="font-medium text-sm mb-3">Last 5 Matches</h4>
                      <div className="space-y-2">
                        {h2h.last5Matches.map((match, matchIndex) => (
                          <div key={matchIndex} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded border">
                            <div className="flex-1">
                              <div className="text-xs text-muted-foreground">{match.date}</div>
                              <div className="text-sm font-medium">{match.homeTeam} vs {match.awayTeam}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold">{match.homeScore} - {match.awayScore}</span>
                              {getResultBadge(match.result)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Statistics Summary Rectangle */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-3">
                        <h5 className="font-medium text-sm mb-2 text-blue-700 dark:text-blue-300">{h2h.team1}</h5>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span>Win Rate</span>
                            <span className="font-medium">{Math.round((h2h.team1Wins / h2h.totalMatches) * 100)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Avg Goals</span>
                            <span className="font-medium">{(h2h.team1Goals / h2h.totalMatches).toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-red-50 dark:bg-red-950/20 rounded-lg p-3">
                        <h5 className="font-medium text-sm mb-2 text-red-700 dark:text-red-300">{h2h.team2}</h5>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span>Win Rate</span>
                            <span className="font-medium">{Math.round((h2h.team2Wins / h2h.totalMatches) * 100)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Avg Goals</span>
                            <span className="font-medium">{(h2h.team2Goals / h2h.totalMatches).toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Team Form Cards */}
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-4">Current Team Form</h3>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {Object.entries(teamForms).map(([team, form]) => (
                  <TeamFormCard key={team} team={team} form={form} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Top Scorers
                  </CardTitle>
                  <CardDescription>Leading goal scorers across all leagues</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {topScorers.slice(0, 10).map((scorer) => (
                        <div key={scorer.rank} className="flex items-center justify-between p-3 rounded-lg border bg-gradient-to-r from-blue-50 to-transparent dark:from-blue-950/20 dark:to-transparent">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center font-bold">
                              {scorer.rank}
                            </Badge>
                            <Avatar className="w-10 h-10">
                              <AvatarFallback className="font-bold">{scorer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-semibold text-sm">{scorer.name}</p>
                              <p className="text-xs text-muted-foreground">{scorer.team}</p>
                              <Badge variant="secondary" className="text-xs mt-1">{scorer.league}</Badge>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="text-center bg-green-50 dark:bg-green-950/20 rounded-lg p-2">
                              <p className="font-bold text-lg text-green-600">{scorer.goals}</p>
                              <p className="text-muted-foreground text-xs">Goals</p>
                            </div>
                            <div className="text-center bg-blue-50 dark:bg-blue-950/20 rounded-lg p-2">
                              <p className="font-medium text-blue-600">{scorer.assists}</p>
                              <p className="text-muted-foreground text-xs">Assists</p>
                            </div>
                            <div className="text-center bg-amber-50 dark:bg-amber-950/20 rounded-lg p-2">
                              <p className="font-medium text-amber-600">{scorer.matches}</p>
                              <p className="text-muted-foreground text-xs">Matches</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Team Statistics
                  </CardTitle>
                  <CardDescription>Top performing teams this season</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {teamStats.map((team, index) => (
                        <div key={index} className="border rounded-lg p-4 bg-gradient-to-r from-purple-50 to-transparent dark:from-purple-950/20 dark:to-transparent">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h3 className="font-semibold">{team.team}</h3>
                              <Badge variant="outline" className="text-xs">{team.league}</Badge>
                            </div>
                            <div className="text-right bg-green-50 dark:bg-green-950/20 rounded-lg px-3 py-1">
                              <div className="text-lg font-bold text-green-600">{team.points || (team.won * 3 + team.drawn)} pts</div>
                              <div className="text-xs text-muted-foreground">{team.played} games</div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-3 mb-3">
                            <div className="text-center bg-green-50 dark:bg-green-950/20 rounded-lg p-2">
                              <div className="font-bold text-green-600">{team.won}</div>
                              <div className="text-xs text-muted-foreground">Won</div>
                            </div>
                            <div className="text-center bg-yellow-50 dark:bg-yellow-950/20 rounded-lg p-2">
                              <div className="font-bold text-yellow-600">{team.drawn}</div>
                              <div className="text-xs text-muted-foreground">Drawn</div>
                            </div>
                            <div className="text-center bg-red-50 dark:bg-red-950/20 rounded-lg p-2">
                              <div className="font-bold text-red-600">{team.lost}</div>
                              <div className="text-xs text-muted-foreground">Lost</div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3 text-xs">
                            <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-2">
                              <div className="flex justify-between">
                                <span>Goals:</span>
                                <span className="font-medium">{team.goalsFor}:{team.goalsAgainst}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Clean Sheets:</span>
                                <span className="font-medium">{team.cleanSheets}</span>
                              </div>
                            </div>
                            <div className="bg-amber-50 dark:bg-amber-950/20 rounded-lg p-2">
                              <div className="flex justify-between">
                                <span>Possession:</span>
                                <span className="font-medium">{team.possession}%</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Pass Acc:</span>
                                <span className="font-medium">{team.passAccuracy}%</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Today's AI Predictions
                  </CardTitle>
                  <CardDescription>Machine-powered match analysis and tips</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {matches.filter(m => m.prediction).map((match) => (
                      <div key={match.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="font-medium">
                            {match.homeTeam} vs {match.awayTeam}
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{match.prediction?.confidence}%</Badge>
                            <Button size="sm" variant="ghost">
                              <ThumbsUp className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <ThumbsDown className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                            <span className="text-sm">Prediction: {match.prediction?.winner}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {match.prediction?.tips.map((tip, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tip}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    AI Accuracy Stats
                  </CardTitle>
                  <CardDescription>Our prediction performance this week</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Overall Accuracy</span>
                        <span className="text-sm text-muted-foreground">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Match Winner</span>
                        <span className="text-sm text-muted-foreground">82%</span>
                      </div>
                      <Progress value={82} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Over/Under Goals</span>
                        <span className="text-sm text-muted-foreground">71%</span>
                      </div>
                      <Progress value={71} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Both Teams Score</span>
                        <span className="text-sm text-muted-foreground">69%</span>
                      </div>
                      <Progress value={69} className="h-2" />
                    </div>
                    <div className="pt-4 border-t">
                      <div className="flex items-center justify-between text-sm">
                        <span>Total Predictions</span>
                        <span className="font-medium">156</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Successful</span>
                        <span className="font-medium text-green-600">122</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Failed</span>
                        <span className="font-medium text-red-600">34</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="news" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {sportsNews.map((article) => (
                <NewsArticleCard key={article.id} article={article} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Bottom Navigation for Mobile/Tablet */}
      {showBottomNav && (
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-2 z-50 md:hidden">
          <div className="flex justify-around items-center max-w-lg mx-auto">
            <button
              onClick={() => setSelectedTab('livescore')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'livescore' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Zap className="w-5 h-5" />
              <span className="text-xs">Live</span>
            </button>
            <button
              onClick={() => setSelectedTab('fixtures')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'fixtures' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <CalendarDays className="w-5 h-5" />
              <span className="text-xs">Fixtures</span>
            </button>
            <button
              onClick={() => setSelectedTab('previous')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'previous' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <History className="w-5 h-5" />
              <span className="text-xs">Results</span>
            </button>
            <button
              onClick={() => setSelectedTab('news')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'news' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Newspaper className="w-5 h-5" />
              <span className="text-xs">News</span>
            </button>
            <button
              onClick={() => setSelectedTab('stats')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'stats' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-xs">Stats</span>
            </button>
            <button
              onClick={() => setSelectedTab('head2head')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'head2head' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <TargetIcon className="w-5 h-5" />
              <span className="text-xs">H2H</span>
            </button>
            <button
              onClick={() => setSelectedTab('predictions')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'predictions' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Target className="w-5 h-5" />
              <span className="text-xs">AI</span>
            </button>
          </div>
        </div>
      )}
      
      {selectedMatch && (
        <MatchDetailsDialog
          match={selectedMatch}
          open={showMatchDetails}
          onOpenChange={setShowMatchDetails}
        />
      )}
    </div>
  )
}