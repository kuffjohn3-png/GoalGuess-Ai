'use client'

import { useState } from 'react'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  Target, 
  Shield, 
  Users, 
  Calendar,
  MapPin,
  Cloud,
  Trophy,
  Star,
  BarChart3,
  TrendingUp,
  AlertTriangle
} from 'lucide-react'

interface MatchDetailsProps {
  match: {
    id: string
    homeTeam: string
    awayTeam: string
    league: string
    leagueFlag: string
    status: string
    homeScore?: number
    awayScore?: number
    minute?: number
    venue?: string
  }
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function MatchDetailsDialog({ match, open, onOpenChange }: MatchDetailsProps) {
  const [details, setDetails] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const fetchMatchDetails = async () => {
    setLoading(true)
    try {
      const response = await fetch(
        `/api/match-details?homeTeam=${encodeURIComponent(match.homeTeam)}&awayTeam=${encodeURIComponent(match.awayTeam)}&league=${encodeURIComponent(match.league)}`
      )
      const data = await response.json()
      if (data.success) {
        setDetails(data.data)
      }
    } catch (error) {
      console.error('Failed to fetch match details:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleOpenChange = (isOpen: boolean) => {
    onOpenChange(isOpen)
    if (isOpen && !details) {
      fetchMatchDetails()
    }
  }

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-200"></div>
            <span className="ml-2">Loading match details...</span>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <span className="text-2xl">{match.leagueFlag}</span>
            <div className="flex items-center gap-2">
              <span>{match.homeTeam}</span>
              <span className="text-gray-500">vs</span>
              <span>{match.awayTeam}</span>
            </div>
            <Badge variant="outline">{match.league}</Badge>
          </DialogTitle>
          <DialogDescription>
            Detailed match analysis, statistics, and betting markets
          </DialogDescription>
        </DialogHeader>

        {details && (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="markets">Markets</TabsTrigger>
              <TabsTrigger value="statistics">Statistics</TabsTrigger>
              <TabsTrigger value="head2head">H2H</TabsTrigger>
              <TabsTrigger value="players">Players</TabsTrigger>
              <TabsTrigger value="predictions">Predictions</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Venue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="text-lg font-semibold">{details.overview.venue}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Date & Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">{new Date(details.overview.date).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Weather</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <Cloud className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">{details.overview.weather}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Attendance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span className="text-lg font-semibold">{details.overview.attendance.toLocaleString()}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      {details.homeTeam} Tactical Setup
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <span className="text-sm text-gray-500">Formation</span>
                      <p className="font-semibold">{details.tacticalAnalysis.homeTeam.formation}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Playing Style</span>
                      <p className="font-semibold">{details.tacticalAnalysis.homeTeam.style}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Strengths</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {details.tacticalAnalysis.homeTeam.strengths.map((strength: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {strength}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      {details.awayTeam} Tactical Setup
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <span className="text-sm text-gray-500">Formation</span>
                      <p className="font-semibold">{details.tacticalAnalysis.awayTeam.formation}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Playing Style</span>
                      <p className="font-semibold">{details.tacticalAnalysis.awayTeam.style}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Strengths</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {details.tacticalAnalysis.awayTeam.strengths.map((strength: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {strength}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="markets" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="w-5 h-5" />
                      1X2 Market
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-2">
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="font-bold text-lg">{details.markets['1X2'].homeWin}</div>
                        <div className="text-xs text-gray-600">{match.homeTeam}</div>
                        <div className="text-xs text-green-600">{details.markets['1X2'].impliedProbability.home}%</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="font-bold text-lg">{details.markets['1X2'].draw}</div>
                        <div className="text-xs text-gray-600">Draw</div>
                        <div className="text-xs text-gray-600">{details.markets['1X2'].impliedProbability.draw}%</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <div className="font-bold text-lg">{details.markets['1X2'].awayWin}</div>
                        <div className="text-xs text-gray-600">{match.awayTeam}</div>
                        <div className="text-xs text-red-600">{details.markets['1X2'].impliedProbability.away}%</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Over/Under Goals
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-center p-2 bg-blue-50 rounded">
                        <div className="font-bold">Over 2.5</div>
                        <div className="text-sm">{details.markets.overUnder.over2_5}</div>
                      </div>
                      <div className="text-center p-2 bg-blue-50 rounded">
                        <div className="font-bold">Under 2.5</div>
                        <div className="text-sm">{details.markets.overUnder.under2_5}</div>
                      </div>
                    </div>
                    <Separator />
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-center p-2 bg-purple-50 rounded">
                        <div className="font-bold">BTTS Yes</div>
                        <div className="text-sm">{details.markets.overUnder.btts.yes}</div>
                      </div>
                      <div className="text-center p-2 bg-purple-50 rounded">
                        <div className="font-bold">BTTS No</div>
                        <div className="text-sm">{details.markets.overUnder.btts.no}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="statistics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      {details.homeTeam} Statistics
                    </CardTitle>
                    <CardDescription>League Position: #{details.teamStats.homeTeam.leaguePosition}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-gray-500">Goals Scored</span>
                        <p className="font-semibold text-lg">{details.teamStats.homeTeam.goalsScored}</p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-500">Goals Conceded</span>
                        <p className="font-semibold text-lg">{details.teamStats.homeTeam.goalsConceded}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>Possession</span>
                          <span>{details.teamStats.homeTeam.avgPossession}%</span>
                        </div>
                        <Progress value={details.teamStats.homeTeam.avgPossession} className="h-2" />
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Recent Form</span>
                      <div className="flex gap-1 mt-1">
                        {details.teamStats.homeTeam.recentForm.map((result: string, index: number) => (
                          <Badge key={index} variant="outline" className="w-8 h-8 p-0 flex items-center justify-center">
                            {getFormBadge(result)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      {details.awayTeam} Statistics
                    </CardTitle>
                    <CardDescription>League Position: #{details.teamStats.awayTeam.leaguePosition}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-gray-500">Goals Scored</span>
                        <p className="font-semibold text-lg">{details.teamStats.awayTeam.goalsScored}</p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-500">Goals Conceded</span>
                        <p className="font-semibold text-lg">{details.teamStats.awayTeam.goalsConceded}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>Possession</span>
                          <span>{details.teamStats.awayTeam.avgPossession}%</span>
                        </div>
                        <Progress value={details.teamStats.awayTeam.avgPossession} className="h-2" />
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Recent Form</span>
                      <div className="flex gap-1 mt-1">
                        {details.teamStats.awayTeam.recentForm.map((result: string, index: number) => (
                          <Badge key={index} variant="outline" className="w-8 h-8 p-0 flex items-center justify-center">
                            {getFormBadge(result)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="head2head" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Total Matches</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{details.headToHead.totalMatches}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">{match.homeTeam} Wins</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">{details.headToHead.homeWins}</div>
                    <div className="text-sm text-gray-500">
                      {((details.headToHead.homeWins / details.headToHead.totalMatches) * 100).toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">Draws</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-yellow-600">{details.headToHead.draws}</div>
                    <div className="text-sm text-gray-500">
                      {((details.headToHead.draws / details.headToHead.totalMatches) * 100).toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">{match.awayTeam} Wins</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">{details.headToHead.awayWins}</div>
                    <div className="text-sm text-gray-500">
                      {((details.headToHead.awayWins / details.headToHead.totalMatches) * 100).toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    Recent Head-to-Head Matches
                  </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {details.headToHead.last5Matches.map((h2hMatch, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="text-sm text-gray-500">
                                {new Date(h2hMatch.date).toLocaleDateString()}
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{h2hMatch.homeTeam}</span>
                                <span className="font-bold">{h2hMatch.homeScore} - {h2hMatch.awayScore}</span>
                                <span className="font-medium">{h2hMatch.awayTeam}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {getResultBadge(h2hMatch.result)}
                              <Badge variant="outline" className="text-xs">{h2hMatch.competition}</Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="players" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="w-5 h-5" />
                      {details.homeTeam} Key Players
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {details.keyPlayers.homeTeam.map((player, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <div className="font-semibold">{player.name}</div>
                              <div className="text-sm text-gray-500">{player.position}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold">{player.avgRating}</div>
                              <div className="text-xs text-gray-500">Rating</div>
                            </div>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <span className="text-gray-500">Goals</span>
                              <div className="font-semibold">{player.goals}</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Assists</span>
                              <div className="font-semibold">{player.assists}</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Shots</span>
                              <div className="font-semibold">{player.shots}</div>
                            </div>
                          </div>
                          <div className="mt-2">
                            <div className="flex justify-between text-xs">
                              <span>Pass Accuracy</span>
                              <span>{player.passAccuracy}%</span>
                            </div>
                            <Progress value={player.passAccuracy} className="h-1" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="w-5 h-5" />
                      {details.awayTeam} Key Players
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {details.keyPlayers.awayTeam.map((player, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <div className="font-semibold">{player.name}</div>
                              <div className="text-sm text-gray-500">{player.position}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold">{player.avgRating}</div>
                              <div className="text-xs text-gray-500">Rating</div>
                            </div>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <span className="text-gray-500">Goals</span>
                              <div className="font-semibold">{player.goals}</div>
                            </div>
                          <div>
                              <span className="text-gray-500">Assists</span>
                              <div className="font-semibold">{player.assists}</div>
                            </div>
                        <div>
                              <span className="text-gray-500">Shots</span>
                              <div className="font-semibold">{player.shots}</div>
                            </div>
                          </div>
                          <div className="mt-2">
                            <div className="flex justify-between text-xs">
                              <span>Pass Accuracy</span>
                              <span>{player.passAccuracy}%</span>
                            </div>
                            <Progress value={player.passAccuracy} className="h-1" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="predictions" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Match Prediction
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-700">{details.predictions.winner}</div>
                      <div className="text-sm text-gray-600">Predicted Winner</div>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-700">{details.predictions.score}</div>
                      <div className="text-sm text-gray-600">Predicted Score</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-700">{details.predictions.confidence}%</div>
                      <div className="text-sm text-gray-600">Confidence</div>
                    </div>
                  </div>

                  <div>
                    <span className="text-sm text-gray-500">Risk Level</span>
                    <div className="mt-1">
                      <Badge className={getRiskColor(details.predictions.riskLevel)}>
                        {details.predictions.riskLevel} Risk
                      </Badge>
                    </div>
                  </div>

                  <div>
                    <span className="text-sm text-gray-500">Analysis</span>
                    <p className="text-sm mt-1">{details.predictions.reasoning}</p>
                  </div>

                  <div>
                    <span className="text-sm text-gray-500">Key Factors</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {details.predictions.keyFactors.map((factor, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {factor}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Recommended Bets
                  </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {details.predictions.recommendedBets.map((bet, index) => (
                        <div key={index} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <div className="font-semibold">{bet.market}</div>
                              <div className="text-sm text-gray-600">{bet.selection}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold">{bet.odds}</div>
                              <div className="text-xs text-gray-500">Odds</div>
                            </div>
                          </div>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-gray-500">Confidence:</span>
                              <Badge variant="outline">{bet.confidence}%</Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600">{bet.reasoning}</p>
                        </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  )
}

// Helper functions
const getResultBadge = (result: string) => {
  switch (result) {
    case 'home':
      return <Badge className="bg-green-500 text-white">Home</Badge>
    case 'away':
      return <Badge className="bg-red-500 text-white">Away</Badge>
    case 'draw':
      return <Badge className="bg-yellow-500 text-white">Draw</Badge>
    default:
      return null
  }
}

const getFormBadge = (result: string) => {
  switch (result) {
    case 'W':
      return <Badge className="bg-green-500 text-white w-6 h-6 p-0">W</Badge>
    case 'L':
      return <Badge className="bg-red-500 text-white w-6 h-6 p-0">L</Badge>
    case 'D':
      return <Badge className="bg-yellow-500 text-white w-6 h-6 p-0">D</Badge>
    default:
      return null
  }
}

const getRiskColor = (risk: string) => {
  switch (risk) {
    case 'Low':
      return 'text-green-600 bg-green-50'
    case 'Medium':
      return 'text-yellow-600 bg-yellow-50'
    case 'High':
      return 'text-red-600 bg-red-50'
    default:
      return 'text-gray-600 bg-gray-50'
  }
}