'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  TrendingUp, 
  Users, 
  Calendar,
  Clock,
  Target,
  Zap,
  Shield,
  Star,
  Trophy,
  Home,
  User,
  Timer,
  Tv,
  Award,
  TargetIcon,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Wifi,
  WifiOff,
  Bell,
  History,
  CalendarDays,
  TrendingDown,
  BarChart3,
  MapPin,
  Filter,
  Search,
  Menu,
  X,
  ArrowUp,
  MessageSquare,
  Share2,
  Bookmark,
  Plus,
  Minus,
  Info,
  ChevronDown,
  RefreshCw
  DollarSign,
  TrendingUp as TrendingUpIcon
} from 'lucide-react'

interface MatchDetails {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  date: string
  time: string
  venue: string
  attendance: number
  league: string
  leagueFlag: string
  homeTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  awayTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  markets?: {
    overUnder?: {
      line: number
      overOdds: number
      underOdds: number
    }
    bothTeamsScore?: {
      yesOdds: number
      noOdds: number
    }
    correctScore?: {
      homeExactOdds: number
      drawOdds: number
      awayExactOdds: number
    }
    halfTimeFullTime?: {
      homeOdds: number
      drawOdds: number
      awayOdds: number
    }
    firstGoalScorer?: {
      options: Array<{
        player: string
        odds: number
      }>
    }
    matchWinner?: {
      homeOdds: number
      drawOdds: number
      awayOdds: number
    }
  }
  events?: Array<{
    minute: number
    type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'halftime' | 'fulltime'
    player: string
    team: 'home' | 'away'
    description: string
  }>
  prediction?: {
    winner: string
    confidence: number
    tips: string[]
    reasoning?: string
  }
}

interface BetSlip {
  id: string
  userId: string
  matchId: string
  betType: string
  market: string
  selection: string
  odds: number
  stake: number
  status: 'pending' | 'won' | 'lost' | 'pushed' | 'voided'
  potentialWinnings: number
  createdAt: string
}

const MatchDetailsCard = ({ match }: { match: MatchDetails }) => {
  const [activeTab, setActiveTab] = useState('overview')
  const [betAmount, setBetAmount] = useState(10)
  const [selectedMarket, setSelectedMarket] = useState('overUnder')
  const [showBetSlip, setShowBetSlip] = useState(false)

  const getMarketDisplay = (market: string, value: any) => {
    switch (market) {
      case 'overUnder':
        return `${value} (Over/Under ${value.line})`
      case 'bothTeamsScore':
        return value ? 'Yes' : 'No'
      case 'correctScore':
        return value
      case 'halfTimeFullTime':
        return value
      case 'firstGoalScorer':
        return value.player
      case 'matchWinner':
        return value
      default:
        return value
    }
  }

  const EventIcon = ({ type, team }: { type: string, team: 'home' | 'away' }) => {
    switch (type) {
      case 'goal':
        return <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-xs">⚽</div>
      case 'yellow_card':
        return <div className="w-4 h-4 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold text-xs">🟨</div>
      case 'red_card':
        return <div className="w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-xs">🟥</div>
      case 'substitution':
        return <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-xs">🔄</div>
      case 'halftime':
        return <div className="w-4 h-4 bg-gray-500 rounded-full flex items-center justify-center text-white font-bold text-xs">HT</div>
      case 'fulltime':
        return <div className="w-4 h-4 bg-gray-500 rounded-full flex items-center justify-center text-white font-bold text-xs">FT</div>
      default:
        return null
    }
  }

  const placeBet = (market: string, selection: string) => {
    setShowBetSlip(true)
    // Here you would integrate with your betting API
    console.log(`Placing bet: ${market} - ${selection}`)
  }

  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="text-lg font-bold">
                {match.homeTeam.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="text-center">
              <div className="text-2xl font-bold">{match.homeScore}</div>
              <div className="text-sm text-muted-foreground">vs</div>
              <div className="text-2xl font-bold">{match.awayScore}</div>
            </div>
            <Avatar className="w-10 h-10">
              <AvatarFallback className="text-lg font-bold">
                {match.awayTeam.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={match.status === 'live' ? 'destructive' : match.status === 'finished' ? 'secondary' : 'outline'} className="text-xs">
                {match.status === 'live' ? (
                  <>
                    <Clock className="w-3 h-3 mr-1" />
                    LIVE {match.minute && `${minute}'`}
                  </>
                ) : match.status === 'finished' ? 'FT' : 'UPCOMING'}
              </Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {match.date} at {match.time}
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center gap-2">
            <span className="text-lg">{match.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{match.league}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
            <TabsTrigger value="events">Events</TabsTrigger>
            <TabsTrigger value="markets">Markets</TabsTrigger>
            <TabsTrigger value="prediction">AI Prediction</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold mb-2">Match Information</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Venue:</span>
                    <span>{match.venue}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Attendance:</span>
                    <span>{match.attendance?.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date:</span>
                    <span>{match.date} at {match.time}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold mb-2">Team Statistics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium text-center mb-2">{match.homeTeam}</h4>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Possession</span>
                        <span>{match.homeTeamStats?.possession}%</span>
                      </div>
                      <Progress value={match.homeTeamStats?.possession || 0} className="h-2" />
                      <div className="flex justify-between text-sm">
                        <span>Shots</span>
                        <span>{match.homeTeamStats?.shots}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Shots on Target</span>
                        <span>{match.homeTeamStats?.shotsOnTarget}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>xG</span>
                        <span>{match.homeTeamStats?.xG}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-center mb-2">{match.awayTeam}</h4>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Possession</span>
                        <span>{match.awayTeamStats?.possession}%</span>
                      </div>
                      <Progress value={match.awayTeamStats?.possession || 0} className="h-2" />
                      <div className="flex justify-between text-sm">
                        <span>Shots</span>
                        <span>{match.awayTeamStats?.shots}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Shots on Target</span>
                        <span>{match.awayTeamStats?.shotsOnTarget}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>xG</span>
                        <span>{match.awayTeamStats?.xG}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {match.prediction && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold mb-2">AI Prediction</h3>
                <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Prediction:</span>
                    <Badge variant="outline" className="text-xs">
                      {match.prediction.winner} ({match.prediction.confidence}%)
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {match.prediction.reasoning}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {match.prediction.tips.map((tip, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {tip}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="statistics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold mb-2">Advanced Stats</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Total Shots</span>
                      <span>{(match.homeTeamStats?.shots || 0) + (match.awayTeamStats?.shots || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shots on Target</span>
                      <span>{(match.homeTeamStats?.shotsOnTarget || 0) + (match.awayTeamStats?.shotsOnTarget || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Corners</span>
                      <span>{(match.homeTeamStats?.corners || 0) + (match.awayTeamStats?.corners || 0)}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Fouls</span>
                      <span>{(match.homeTeamStats?.fouls || 0) + (match.awayTeamStats?.fouls || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Yellow Cards</span>
                      <span>{(match.homeTeamStats?.yellowCards || 0) + (match.awayTeamStats?.yellowCards || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Red Cards</span>
                      <span>{(match.homeTeamStats?.redCards || 0) + (match.awayTeamStats?.redCards || 0)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="events" className="space-y-6">
            <ScrollArea className="h-64">
              <div className="space-y-4">
                {match.events?.map((event, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                    <div className="flex-shrink-0">
                      <EventIcon type={event.type} team={event.team} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-muted-foreground">{event.minute}'</span>
                        <span className="text-sm">{event.description}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">{event.player}</span>
                    </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="markets" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">Betting Markets</h3>
              <div className="grid gap-4">
                {match.markets?.overUnder && (
                  <div className="space-y-4 p-4 bg-muted rounded-lg">
                    <h4 className="font-medium mb-2">Over/Under {match.markets.overUnder.line}</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex justify-between">
                        <span>Over</span>
                        <span>{match.markets.overUnder.overOdds}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Under</span>
                        <span>{match.markets.overUnder.underOdds}</span>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button 
                        onClick={() => placeBet('overUnder', 'over')}
                        className="w-full"
                        variant={selectedMarket === 'overUnder' ? 'default' : 'outline'}
                      >
                        Bet Over {betAmount}€
                      </Button>
                      <Button 
                        onClick={() => placeBet('overUnder', 'under')}
                        className="w-full"
                        variant={selectedMarket === 'overUnder' ? 'outline' : 'default'}
                      >
                        Bet Under {betAmount}€
                      </Button>
                    </div>
                  </div>
                )}

                {match.markets?.bothTeamsScore && (
                  <div className="space-y-4 p-4 bg-muted rounded-lg">
                    <h4 className="font-medium mb-2">Both Teams to Score</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex justify-between">
                        <span>Yes</span>
                        <span>{match.markets.bothTeamsScore.yesOdds}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>No</span>
                        <span>{match.markets.bothTeamsScore.noOdds}</span>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button 
                        onClick={() => placeBet('bothTeamsScore', 'yes')}
                        className="w-full"
                        variant={selectedMarket === 'bothTeamsScore' ? 'default' : 'outline'}
                      >
                        Bet Yes {betAmount}€
                      </Button>
                      <Button 
                        onClick={() => placeBet('bothTeamsScore', 'no')}
                        className="w-full"
                        variant={selectedMarket === 'bothTeamsScore' ? 'outline' : 'default'}
                      >
                        Bet No {betAmount}€
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="prediction" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-2">Detailed AI Analysis</h3>
              <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-4">
                <h4 className="font-medium mb-2">Market Analysis</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Confidence Level:</span>
                    <Badge variant="outline" className="text-xs">
                      {match.prediction.confidence > 75 ? 'High' : match.prediction.confidence > 60 ? 'Medium' : 'Low'}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Expected Value:</span>
                    <span className="text-green-600">Value Bet</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Stake Amount:</div>
            <div className="flex items-center gap-2">
              <Button 
                onClick={() => setBetAmount(Math.max(1, betAmount - 10))}
                variant="outline" 
                size="sm"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span className="text-lg font-bold">{betAmount}€</span>
              <Button 
                onClick={() => setBetAmount(Math.min(1000, betAmount + 10))}
                variant="outline" 
                size="sm"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <Button 
              onClick={() => setShowBetSlip(true)}
              className="w-full"
              size="lg"
            >
              Place Bet
            </Button>
          </div>
        </CardContent>
      </Card>
    </Card>
  )
}

export default MatchDetailsCard