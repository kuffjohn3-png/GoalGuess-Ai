import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface DatabaseMatch {
  id: string
  home_team: string
  away_team: string
  home_score: number
  away_score: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  league_flag: string
  venue: string
  attendance?: number
  date: string
  kickoff_time: string
  created_at: string
  updated_at: string
}

export interface DatabaseTeam {
  id: string
  name: string
  country: string
  logo_url?: string
  founded_year: number
  stadium: string
  colors: {
    primary: string
    secondary: string
    accent: string
  }
  created_at: string
  updated_at: string
}

export interface DatabaseLeague {
  id: string
  name: string
  country: string
  flag: string
  teams_count: number
  matches_count: number
  season: string
  start_date: string
  end_date: string
  logo_url?: string
  created_at: string
  updated_at: string
}

export interface DatabasePlayer {
  id: string
  name: string
  team_id: string
  position: string
  age: number
  nationality: string
  height: number
  weight: number
  photo_url?: string
  goals: number
  assists: number
  yellow_cards: number
  red_cards: number
  appearances: number
  created_at: string
  updated_at: string
}

export interface DatabaseBettingMarket {
  id: string
  match_id: string
  market_type: 'over_under' | 'both_teams_to_score' | 'corners' | 'cards' | 'handicap' | 'correct_score'
  market_name: string
  odds: number
  probability: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface DatabaseMatchDetail {
  id: string
  match_id: string
  home_team_id: string
  away_team_id: string
  home_score: number
  away_score: number
  minute: number
  event_type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'corner' | 'offside'
  player_id?: string
  player_name?: string
  team: 'home' | 'away'
  description: string
  created_at: string
}

export interface DatabaseHeadToHead {
  id: string
  team1_id: string
  team2_id: string
  total_matches: number
  team1_wins: number
  team2_wins: number
  draws: number
  team1_goals: number
  team2_goals: number
  team1_clean_sheets: number
  team2_clean_sheets: number
  last_match_date: string
  created_at: string
  updated_at: string
}