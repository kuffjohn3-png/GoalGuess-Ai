# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# Database Schema
# Create tables: matches, teams, players, leagues, markets, odds, news, users, predictions

# Environment Variables
# Copy these to your .env.local file