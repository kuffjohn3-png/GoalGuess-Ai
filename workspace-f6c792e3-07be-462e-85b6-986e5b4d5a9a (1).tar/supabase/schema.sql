// This is your Supabase database schema.
// Use this file to create tables in your Supabase project.

-- Create tables in the following order:
-- 1. Teams table (referenced by other tables)
-- 2. Leagues table (referenced by other tables)
-- 3. Players table (referenced by other tables)
-- 4. Matches table (main table)
-- 5. Match details table
-- 6. Head to head records
-- 7. Betting markets table
-- 8. User predictions and activity

-- Teams table
CREATE TABLE teams (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  country TEXT NOT NULL,
  logo_url TEXT,
  founded_year INTEGER,
  stadium TEXT,
  primary_color TEXT,
  secondary_color TEXT,
  accent_color TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Leagues table
CREATE TABLE leagues (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  country TEXT NOT NULL,
  flag TEXT NOT NULL,
  teams_count INTEGER DEFAULT 20,
  matches_count INTEGER,
  season TEXT,
  start_date DATE,
  end_date DATE,
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Players table
CREATE TABLE players (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  position TEXT,
  age INTEGER,
  nationality TEXT,
  height INTEGER,
  weight INTEGER,
  photo_url TEXT,
  goals INTEGER DEFAULT 0,
  assists INTEGER DEFAULT 0,
  yellow_cards INTEGER DEFAULT 0,
  red_cards INTEGER DEFAULT 0,
  appearances INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Matches table
CREATE TABLE matches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  home_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  away_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  league_id UUID REFERENCES leagues(id) ON DELETE CASCADE,
  home_score INTEGER DEFAULT 0,
  away_score INTEGER DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('live', 'finished', 'upcoming')),
  minute INTEGER,
  venue TEXT,
  attendance INTEGER,
  date DATE NOT NULL,
  kickoff_time TIME,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Match details table (for events during matches)
CREATE TABLE match_details (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  match_id UUID REFERENCES matches(id) ON DELETE CASCADE,
  home_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  away_team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  home_score INTEGER DEFAULT 0,
  away_score INTEGER DEFAULT 0,
  minute INTEGER NOT NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('goal', 'yellow_card', 'red_card', 'substitution', 'corner', 'offside')),
  player_id UUID REFERENCES players(id) ON DELETE CASCADE,
  player_name TEXT,
  team TEXT NOT NULL CHECK (team IN ('home', 'away')),
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Head to head records
CREATE TABLE head_to_head (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  team1_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  team2_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  total_matches INTEGER DEFAULT 0,
  team1_wins INTEGER DEFAULT 0,
  team2_wins INTEGER DEFAULT 0,
  draws INTEGER DEFAULT 0,
  team1_goals INTEGER DEFAULT 0,
  team2_goals INTEGER DEFAULT 0,
  team1_clean_sheets INTEGER DEFAULT 0,
  team2_clean_sheets INTEGER DEFAULT 0,
  last_match_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Betting markets table
CREATE TABLE betting_markets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  match_id UUID REFERENCES matches(id) ON DELETE CASCADE,
  market_type TEXT NOT NULL CHECK (market_type IN ('over_under', 'both_teams_to_score', 'corners', 'cards', 'handicap', 'correct_score', 'first_goal_scorer', 'half_time_result')),
  market_name TEXT NOT NULL,
  odds DECIMAL(10, 2),
  probability DECIMAL(5, 2),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- User predictions table
CREATE TABLE user_predictions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  match_id UUID REFERENCES matches(id) ON DELETE CASCADE,
  user_id TEXT, -- Will be connected to auth system later
  predicted_winner TEXT,
  predicted_score TEXT, -- Format: "2-1"
  confidence_level TEXT CHECK (confidence_level IN ('low', 'medium', 'high')),
  prediction_reasoning TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- User activity tracking
CREATE TABLE user_activity (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT,
  activity_type TEXT NOT NULL CHECK (activity_type IN ('prediction_made', 'match_viewed', 'news_shared', 'bet_placed')),
  activity_data JSONB, -- Flexible data structure for different activity types
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for better performance
CREATE INDEX idx_matches_date ON matches(date);
CREATE INDEX idx_matches_status ON matches(status);
CREATE INDEX idx_matches_teams ON matches(home_team_id, away_team_id);
CREATE INDEX idx_matches_league ON matches(league_id);
CREATE INDEX idx_players_team ON players(team_id);
CREATE INDEX idx_match_details_match ON match_details(match_id);
CREATE INDEX idx_head_to_head_teams ON head_to_head(team1_id, team2_id);
CREATE INDEX idx_betting_markets_match ON betting_markets(match_id);
CREATE INDEX idx_user_predictions_match ON user_predictions(match_id);
CREATE INDEX idx_user_activity_user ON user_activity(user_id);

-- Row Level Security Policies (RLS)
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE match_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE leagues ENABLE ROW LEVEL SECURITY;
ALTER TABLE head_to_head ENABLE ROW LEVEL SECURITY;
ALTER TABLE betting_markets ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;