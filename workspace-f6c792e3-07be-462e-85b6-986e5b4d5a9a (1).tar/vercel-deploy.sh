#!/bin/bash

# Vercel Deployment Script for GoalGuess Football Dashboard

echo "🚀 Deploying GoalGuess Football Dashboard to Vercel"
echo "=================================================="

# Check if Vercel is available
if ! command -v npx &> /dev/null; then
    echo "❌ npx not found. Please install Node.js and npm."
    exit 1
fi

echo "✅ Using npx to run Vercel (no global install needed)"

# Deploy using npx
echo "🌐 Starting deployment..."
npx vercel

echo ""
echo "🎉 Deployment process started!"
echo ""
echo "📋 Follow these steps in the Vercel CLI:"
echo "1. Login to your Vercel account (or create one)"
echo "2. Choose 'Link to existing project?' → No"
echo "3. Set project name: goalguess"
echo "4. Set directory: . (current directory)"
echo "5. Override settings? → No"
echo ""
echo "⚙️  After deployment, set these environment variables in Vercel dashboard:"
echo "   - NEXT_PUBLIC_APP_NAME=GoalGuess"
echo "   - NEXT_PUBLIC_APP_URL=https://your-app.vercel.app"
echo "   - NEXT_PUBLIC_SUPABASE_URL=your_supabase_url"
echo "   - NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key"
echo "   - ZAI_API_KEY=your_z_ai_api_key"
echo ""
echo "🌟 Your app will be live at: https://goalguess.vercel.app"